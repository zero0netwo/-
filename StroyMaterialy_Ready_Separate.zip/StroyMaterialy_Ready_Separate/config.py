"""Настройки приложения. Пароль берётся из локального settings.ini или переменных окружения."""
import configparser
import os
import sys
from pathlib import Path

APP_DIR = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
RESOURCE_DIR = APP_DIR / 'resources'
if not RESOURCE_DIR.exists() and getattr(sys, 'frozen', False):
    RESOURCE_DIR = Path(sys._MEIPASS) / 'resources'
PRODUCT_IMAGE_DIR = APP_DIR / 'resources' / 'products'

parser = configparser.ConfigParser()
parser.read(APP_DIR / 'settings.ini', encoding='utf-8')
local = parser['mysql'] if parser.has_section('mysql') else {}

DB_CONFIG = {
    'host': os.getenv('STROY_DB_HOST', local.get('host', 'localhost')),
    'port': int(os.getenv('STROY_DB_PORT', local.get('port', '3306'))),
    'user': os.getenv('STROY_DB_USER', local.get('user', 'root')),
    'password': os.getenv('STROY_DB_PASSWORD', local.get('password', '')),
    'database': os.getenv('STROY_DB_NAME', local.get('database', 'stroymaterialy_exam_db')),
    'connection_timeout': 6,
}


def resource_path(db_path):
    """Находит ресурс по относительному пути из MySQL, независимо от cwd."""
    if not db_path:
        return RESOURCE_DIR / 'picture.png'
    candidate = Path(str(db_path))
    if candidate.is_absolute() and candidate.is_file():
        return candidate
    # Путь SQL хранится как resources/products/<имя>.
    normalized = str(db_path).replace('\\', '/')
    if normalized.startswith('resources/'):
        subpath = normalized.removeprefix('resources/')
        candidate = APP_DIR / 'resources' / subpath
        if candidate.is_file():
            return candidate
        candidate = RESOURCE_DIR / subpath
        if candidate.is_file():
            return candidate
    return RESOURCE_DIR / 'picture.png'
