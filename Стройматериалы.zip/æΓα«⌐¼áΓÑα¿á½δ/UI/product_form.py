import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from decimal import Decimal,  InvalidOperation

from Doc.html.NEWS import description
from PIL import Image

from database import get_product, get_reference, add_product, update_product


BASE_DIR = Path(__file__).resolve().parent.parent

def open_product_form(root, article, on_saved):
    if article:
        product = get_product(article)
    else:
        product = None

    if article and product is None:
        raise ValueError("Товар не найден")

    window = tk.Toplevel(root)

    if product:
        window.title("Редактирование товара")
    else:
        window.title("Добавление товара")

    window.geometry("630x690")
    window.transient(root)
    window.grab_set()

    form = tk.Frame(window)
    form.pack(fill="both", expand=True, padx=18, pady=12)

    form.columnconfigure(1, weight=1)
    row=0

    tk.Label(form, text="ID товара: ").grid(row=row, column=0, sticky="w", pady=4)

    if product:
        product_id_text = str(product[0])
    else:
        product_id_text = "Автоматически"

    tk.Label(form, text="product_id_text").grid(row=row, column=1, sticky="w")

    row +=1

    entries = {}

    fields = [
        ("article", "Артикул", 1)
        ("name", "Название", 2)
        ("price", "Цена", 3)
        ("discount", "Скидка", 4)
        ("stock", "Остаток", 5)

    ]

    for field, title, index in fields:
        tk.Label(form, text=title + ':').grid(row=row, column=0, sticky="w", pady=5)
        entry = tk.Entry(form, width=48)
        entry.grid(row=row, column=1, sticky="ew", padx=8)

        if product:
            entry.insert(0, str(product[index]))
        entries[field] = entry
        row += 1

    boxes = {}

    references = [
        ("categories", "Категория", 3)
        ("manufacturers", "Производитель", 4)
        ("suppliers", "Поставщик", 5)
        ("units", "Единица измерения", 6)
    ]

    for table, title, index in references:
        options = get_reference(table)

        names = [name for key, name in options]

        ids = {name: key for key, name in options}
        tk.Label(form, text=title + ":").grid(row=row, column=0, sticky="w", pady=5)

        box = ttk.Combobox(form, state="readonly", values=names, width=45)
        box.grid(row=row, column=1, sticky="ew", padx=8)

        if product:
            selected = next(
                (
                    name
                    for key, name in options
                    if key == product[index]
                ),
                ""
            )
            box.set(selected)
        elif names:
            box.current(0)

        boxes[table] = (box, ids)
        row += 1

    tk.Label(form, text="Описание:").grid(row=row, column=0, sticky="nw", pady=5)

    description = tk.Text(form, height=4, width=50, wrap="word")
    description.grid(row=row, column=1, sticky="ew", padx=8, pady=5)

    if product and product[10]:
        description.insert("1.0", product[10])

    row += 1

    if product:
        image_path = product[11]
    else:
        image_path = None

    image_note = tk.Label(form, text=image_path or "Будет использована заглушка", anchor="w", wraplength=430)
    image_note.grid(row=row, column=1, sticky="w", padx=8, pady=3)

    tk.Label(form, text="Фото:").grid(row=row, column=0, sticky="w")

    row += 1

    selected_file = None

    def choose_image():
        nonlocal selected_file

        filename = filedialog.askopenfilename(parent=window, title="Выбрать фотографию", filetypes=[("Изображения", "*.png *.jpg *.jpeg")])

        if filename:
            try:
                with Image.open(filename) as source:
                    source.verify()

            except (OSError, ValueError):
                messagebox.showerror("Ошибка", "Выбранный файл не является изображением", parent=window)
                return

            selected_file = filename

            image_note.config(text=Path(filename).name)
    tk.Button(form, text="Выбрать фото", command=choose_image).grid(row=row, column=1, sticky='w', padx=8)

    row += 1

    def save():
        nonlocal image_path

        new_file = None

        try:
            article_text = entries["article"].get().strip()
            name = entries["name"].get().strip()

            if not article_text or not name:
                raise ValueError("Заполните артикул и название товара")

            if len(article_text) > 40:
                raise ValueError("Артикул должен быть не длиннее 40 символов")

            try:
                price = Decimal(
                    entries["price"].get().replace(",", ".")
                )
                discount = Decimal(entries["discount"].get().replace(",", "."))

                stock = int(entries["stock"].get())

            except (InvalidOperation, ValueError):
                raise ValueError("Укажите корректные числа для цены, скидки и остатка")
            if not price.is_finite() or not discount.is_finite():
                raise ValueError("Цена и скидка должны быть обычными числами")

            if price < 0:
                raise ValueError('Цена не может быть отрицательной')

            if stock < 0:
                raise ValueError("Остаток не может быть отрицательным")
            if discount < 0 or discount > 100:
                raise ValueError("Скидка должна быть от 0 до 100%")
            if price > Decimal("99999999.99"):
                raise ValueError("Слишком большая цена")

            selected_ids = []

            for table in (
                "categories",
                "manufacturers",
                "suppliers",
                "units"
            ):
                box, ids = boxes[table]
                selected_ids.append(ids[box.get()])
            if selected_file:
                filename = "product_" + "".join(c for c in article_text if c.isalnum() or c in "-_") + ".jpg"

                if filename == "product_.jpg":
                    raise ValueError("Некорректный артикул для имени файла")

                dest = (BASE_DIR / "resources" / "products" / filename)
                dest.parent.mkdir(parent=True, exist_ok=True)

                counter = 2

                while dest.exists():
                    clean_article = "".join(c for c in article_text if c.isalnum() or c in "-_")

                    dest = (BASE_DIR / "resources" / "products" / f"product_{clean_article}_{counter}.jpg")

                    counter += 1
                with Image.open(selected_file) as source:
                    source = source.convert("RGB")
                    source.thumbnail((300, 200))
                    source.save(dest, format="JPEG")

                new_file = dest
                image_path = "resources/products/" + dest.name
            values = (article_text, name, *selected_ids, price , discount, stock, description.get("1.0", "end").strip(),image_path)

            if product:
                update_product(product[0], values)
            else:
                add_product(values)

            if product and product[11]:
                if product[11] != image_path:
                    old_path = BASE_DIR / product[11]

                    product_dir = (BASE_DIR / "resources" / "products")
                    if old_path.is_file():
                        if old_path.is_relative_to(product_dir):
                            try:
                                old_path.unlink()
                            except OSError:
                                pass

            on_saved()

            messagebox.showinfo("Сохранено", "Товар сохранен", parent=window)
            window.destroy()

        except Exception as error:
            if new_file and new_file.exists():
                try:
                    new_file.unlink()
                except OSError:

            messagebox.showerror("Ошибка", str(error), parent = window)

    tk.Button(form, text="Сохранить", bg="#DAA520", command=save, width=18).grid(row=row, column=1, sticky="w", padx=8, pady=15)
    return window

