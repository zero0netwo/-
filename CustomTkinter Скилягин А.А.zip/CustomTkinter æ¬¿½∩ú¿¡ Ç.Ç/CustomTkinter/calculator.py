import math
import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

window = ctk.CTk()
window.title("Калькулятор")
window.geometry("750x450")

heading_label = ctk.CTkLabel(window, text="Мини-калькулятор", font=("Arial", 24, "bold"))
heading_label.pack(pady=(18, 4))

instruction_label = ctk.CTkLabel(window, text="Введите два числа и операцию (+, -, *, /)")
instruction_label.pack(pady=(0, 10))

entry_value1 = ctk.CTkEntry(window, placeholder_text="Введите первое число", width=400)
entry_value1.pack(pady=8)

entry_value2 = ctk.CTkEntry(window, placeholder_text="Введите второе число", width=400)
entry_value2.pack(pady=8)

operation_entry = ctk.CTkEntry(window, placeholder_text="Выберите операцию: +, -, *, /", width=400)
operation_entry.pack(pady=8)

result_label = ctk.CTkLabel(window, text="", font=("Arial", 16))
result_label.pack(pady=8)


def show_error(message):
    result_label.configure(text=message, text_color="#F87171")


def get_value():
    str_v1 = entry_value1.get().strip()
    str_v2 = entry_value2.get().strip()
    operation = operation_entry.get().strip()

    if not str_v1 or not str_v2 or not operation:
        show_error("Ошибка: заполните все поля")
        return

    try:
        value1 = float(str_v1.replace(",", "."))
        value2 = float(str_v2.replace(",", "."))
    except ValueError:
        show_error("Ошибка: введите корректные числа")
        return

    if not math.isfinite(value1) or not math.isfinite(value2):
        show_error("Ошибка: числа должны быть конечными")
        return

    if operation == "+":
        result = value1 + value2
    elif operation == "-":
        result = value1 - value2
    elif operation == "*":
        result = value1 * value2
    elif operation == "/":
        if value2 == 0:
            show_error("Ошибка: деление на ноль!")
            return
        result = value1 / value2
    else:
        show_error("Ошибка: неверная операция (+, -, *, /)")
        return

    if not math.isfinite(result):
        show_error("Ошибка: результат слишком большой")
        return

    result_label.configure(text=f"Результат: {result:g}", text_color="white")


def clear_fields():
    entry_value1.delete(0, "end")
    entry_value2.delete(0, "end")
    operation_entry.delete(0, "end")
    result_label.configure(text="")


btn_result = ctk.CTkButton(window, text="Посчитать", command=get_value)
btn_result.pack(pady=7)

btn_clear = ctk.CTkButton(window, text="Очистить", command=clear_fields)
btn_clear.pack(pady=7)

btn_exit = ctk.CTkButton(window, text="Выход", command=window.destroy)
btn_exit.pack(pady=7)

window.mainloop()
