import customtkinter as ctk
from customtkinter import *

window = ctk.CTk()
window.geometry("750x450")
window.title("Окно практики")

enter_name_label = ctk.CTkLabel(window, text="Введите имя")
enter_name_label.pack(pady=10)

entry_name = ctk.CTkEntry(window, placeholder_text="Введите имя", width=400)
entry_name.pack(pady=10)


first_label = ctk.CTkLabel(window, text="CustomTkinter", font=("bold", 26))
first_label.pack(pady=30)
second_label = ctk.CTkLabel(window, text="Лабораторная номер 2", font=("Arial", 20))
second_label.pack(pady=30)
tird_label = ctk.CTkLabel(window, text="Основные элементы интерфейса", font=("Arial", 16))
tird_label.pack(pady=30)

def first_btn():
    first_label.configure(text="Доброе утро")

first_button = ctk.CTkButton(window, text="Приветствие",command=first_btn)
first_button.pack(pady=10)

def second_btn():
    window.title("Кнопка 2 была нажата")
second_button = ctk.CTkButton(window, text="Изменить заголовок", command=second_btn)
second_button.pack(pady=10)

def tird_btn():
    window.destroy()

tird_button = ctk.CTkButton(window, text="Выход", command=tird_btn)
tird_button.pack(pady=10)

def get_entry():
    name = entry_name.get()
    if name:
        label_hello = ctk.CTkLabel(window, text=f"Привет, {name}")
        label_hello.pack(anchor="n", pady=10)
    else:
        enter_name_label.configure(text="Поле не должно быть пустым", text_color="red")

btn_send = ctk.CTkButton(window, text="Отправить", command=get_entry)
btn_send.pack(pady=10)



window.mainloop()