"""Проверка структуры SQL-команд без реального MySQL (не интеграционный тест)."""
import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

# Драйвер может отсутствовать при тесте без сети. Подменяем только подключение.
try:
    import mysql.connector
except ImportError:
    mysql = types.ModuleType('mysql')
    mysql.__path__ = []
    connector = types.ModuleType('mysql.connector')
    class DatabaseError(Exception): pass
    connector.Error = DatabaseError
    connector.connect = lambda **_: None
    mysql.connector = connector
    sys.modules['mysql'] = mysql
    sys.modules['mysql.connector'] = connector

import database

class Cursor:
    def __init__(self, db, dictionary=False):
        self.db=db; self.lastrowid=31; self.rowcount=1
        self.dictionary=dictionary
    def execute(self, query, params=()):
        self.db.operations.append((query, params))
        if 'INSERT INTO products' in query:
            assert 'article' in query, 'MySQL products.article requires a non-NULL value'
            assert str(params[0]).startswith('TMP')
        if 'INSERT INTO orders' in query:
            assert len(params) == 6
    def executemany(self, query, values):
        self.db.operations.append((query, tuple(values)))
    def fetchone(self):
        return None
    def close(self): pass

class Connection:
    def __init__(self): self.operations=[];self.commits=0;self.rollbacks=0
    def cursor(self, dictionary=False): return Cursor(self,dictionary)
    def commit(self): self.commits+=1
    def rollback(self): self.rollbacks+=1
    def close(self): pass

class DatabaseMockTests(unittest.TestCase):
    def test_insert_product_has_article_and_updates_generated_id(self):
        db=Connection()
        fields={'name':'Тестовый материал','category_id':1,'manufacturer_id':1,
        'supplier_id':1,'unit_id':1,'price':20,'discount':0,'stock_quantity':12,
        'description':None,'image_path':None}
        with patch.object(database.mysql.connector, 'connect', return_value=db):
            ident=database.save_product(fields)
        self.assertEqual(ident,31)
        self.assertEqual(db.commits,1)
        self.assertTrue(any('article=%s' in q for q,_ in db.operations))
    def test_insert_order_transaction_items(self):
        db=Connection()
        data={'client_id':1,'pickup_point_id':1,'status_id':1,
              'order_date':'2025-01-01','delivery_date':'2025-01-10'}
        with patch.object(database.mysql.connector, 'connect', return_value=db):
            ident=database.save_order(data,[{'product_id':1,'quantity':2},{'product_id':2,'quantity':3}])
        self.assertEqual(ident,31)
        self.assertEqual(db.commits,1)
        self.assertTrue(any('INSERT INTO order_items' in q and len(p)==2 for q,p in db.operations))

if __name__=='__main__': unittest.main()
