"""Форма авторизации и вход гостя."""
import tkinter as tk
from tkinter import ttk, messagebox
import database
from logic import GOLD, WHITE
from ui_common import logo, show_error


def render_login(app):
    outside = tk.Frame(app, bg=WHITE)
    outside.pack(fill='both', expand=True)
    card = tk.Frame(outside, bg=WHITE, highlightbackground='#DEC985', highlightthickness=1)
    card.place(relx=.5, rely=.49, anchor='center', width=480, height=480)
    head = tk.Frame(card, bg=GOLD, height=135)
    head.pack(fill='x')
    head.pack_propagate(False)
    logo(head, width=190, height=90).pack(pady=15)
    tk.Label(card, text='Вход в систему', font=('Calibri', 21, 'bold'), bg=WHITE).pack(pady=(20, 12))
    form = tk.Frame(card, bg=WHITE)
    form.pack(padx=55, fill='x')
    tk.Label(form, text='Логин', bg=WHITE, anchor='w').pack(fill='x')
    login = ttk.Entry(form, font=('Calibri', 12))
    login.pack(fill='x', pady=(3, 12))
    tk.Label(form, text='Пароль', bg=WHITE, anchor='w').pack(fill='x')
    password = ttk.Entry(form, show='●', font=('Calibri', 12))
    password.pack(fill='x', pady=(3, 14))

    def enter():
        username, secret = login.get().strip(), password.get()
        if not username or not secret:
            messagebox.showwarning('Не заполнены поля', 'Введите логин и пароль, затем повторите вход.')
            return
        try:
            user = database.get_user(username, secret)
        except Exception as exc:
            show_error(exc, 'Ошибка авторизации')
            return
        if user is None:
            messagebox.showerror('Неверные данные', 'Учётная запись не найдена. Проверьте логин и пароль.')
            return
        app.show_catalog(user)

    ttk.Button(form, text='Войти', style='Accent.TButton', command=enter).pack(fill='x', pady=(5, 7))
    ttk.Button(form, text='Войти как гость', command=lambda: app.show_catalog(None)).pack(fill='x')
    password.bind('<Return>', lambda event: enter())
    login.focus_set()
    tk.Label(card, text='Доступ: гость · клиент · менеджер · администратор',
             bg=WHITE, fg='#767676', font=('Calibri', 9)).pack(pady=15)
