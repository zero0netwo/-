import customtkinter as ctk

window = ctk.CTk()
window.title("Окно регистрации")
window.geometry("750x450")


name_entry = ctk.CTkEntry(window, placeholder_text="Введите имя", width=400)
name_entry.pack(pady=8)

login_entry = ctk.CTkEntry(window, placeholder_text="Введите логин", width=400)
login_entry.pack(pady=8)

password_entry = ctk.CTkEntry(window, placeholder_text="Введите пароль", width=400, show="*")
password_entry.pack(pady=8)

error = ctk.CTkLabel(window, text="")

def get_entry():
    name = name_entry.get().strip()
    login = login_entry.get().strip()
    password = password_entry.get().strip()

    if not name or not login or not password:
        error.configure(text="Заполните поля", text_color="red")
        return
    else:
        label_ok = ctk.CTkLabel(window, text=f"Ваше имя: {name}\nВаш логин:{login}")
        label_ok.pack(pady=8)

btn = ctk.CTkButton(window, text="Войти", command=get_entry)
btn.pack(pady=8)

window.mainloop()