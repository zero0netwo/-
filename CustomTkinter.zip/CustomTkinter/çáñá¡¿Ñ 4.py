import customtkinter as ctk
from customtkinter import *

window4 = ctk.CTk()
window4.title("Окно задания 4")
window4.geometry("750x450")

text = ctk.CTkLabel(window4, text="Заполните поле")
text.pack(pady=10)

entry1 = ctk.CTkEntry(window4, width=400)
entry1.pack(pady=30)

def click_first():
    input_entry = entry1.get()
    text.configure(text=f"Было введено: {input_entry}",)

first_button = ctk.CTkButton(window4, text="Получить текст", command=click_first)
first_button.pack(pady=10)

def click_second():
    entry1.delete(0, "end")

second_button = ctk.CTkButton(window4, text="Очистить", command=click_second)
second_button.pack(pady=10)

def click_second():
    entry1.insert(0,"Изучаю Python")

tird_button = ctk.CTkButton(window4, text="Очистить", command=click_second)
tird_button.pack(pady=10)



window4.mainloop()