import tkinter as tk
from UI.login_window import open_login_window
from UI.main_window import open_main_window

root = tk.Tk()
root.title("СтройМатериалы - Авторизация")
root.geometry("420x320")
root.resizable(False, False)

try:
    root.iconbitmap(str(Path(__file__).resolve().parent / "resources" / "icon.ico"))
except tk.TclError:
    pass

open_login_window(root)
root.mainloop()
