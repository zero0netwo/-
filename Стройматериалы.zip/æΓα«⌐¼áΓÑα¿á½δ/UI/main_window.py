
import tkinter as tk
from tkinter import ttk, messagebox
from pathlib import Path
from PIL import Image, ImageTk
from unicodedata import category

from database import get_tovars, get_reference, delete_product
from UI.product_form import open_product_form



BASE_DIR = Path(__file__).resolve().parent.parent

def make_photo(image_path, size=(55, 55)):
    if image_path:
        path = BASE_DIR / image_path
    else:
        path = BASE_DIR / 'resources/picture.png'


    if not path.is_file():
        path = BASE_DIR / 'resources/picture.png'
    try:
        with Image.open(path) as image:
            image.thumbnail(size)
            return ImageTk.PhotoImage(image.copy())

    except (OSError, ValueError):
        return None




def open_main_window(root, user, on_logout):
    for widget in root.winfo_children():
        widget.destroy()

    root.title("СтройМатериалы - Главное окно")
    root.geometry("1150x520")
    root.resizable(True, True)

    full_name = user[1] if user else "Гость"
    role = user[2] if user else "Гость"

    is_manager = role in ("Менеджер", "Администратор")
    is_admin = role == ("Администратор")

    header = tk.Frame(root, bg="#DAA520")
    header.pack(fill="x")

    tk.Label(header, text='Стройматериалы', font=("Calibri", 17, "bold"), bg="#DAA520").pack(side="left", padx=10, pady=10)
    tk.Label(header, text=f"{full_name} ({role})", font=("Calibri", 11), bg="#DAA520").pack(side="right", padx=10)

    tk.Button(header, text="Выйти", command=on_logout).pack(side="right", padx=7)

    actions= tk.Frame(root)
    actions.pack(fill="x", padx=12, pady=7)

    tk.Label(actions, text="Каталог товаров", font=("Calibri", 15, "bold")).pack(side="left")

    if is_manager:
        tk.Button(actions, text="Заказы", command=lambda: show_orders()).pack(side="right", padx=3)

    if is_admin:
        tk.Button(actions, text="Доставить товар", commnd=lambda: show_editor()).pack(side="right", padx=3)
        tk.Button(actions, text="Редактировать", command=lambda: edit_selected()).pack(side="right", padx=3)

        tk.Button(actions, text="удалить", command=lambda: remove_selected()).pack(side='right', padx=3)

    search_var = tk.StringVar()
    manufacturer_var = tk.StringVar(value="Все производители")
    sort_var = tk.StringVar(value="Без сортировки")

    if is_manager:
        filters = tk.Frame(root)
        filter.pack(fill="x", padx=12, pady=(0, 8))

        tk.Label(filters, text="Поиск:").pack(side='left')

        tk.Entry(filters, textvariable=search_var,width=30).pack(side='left', padx=(5,12))

        tk.Label(filters, text="Производитель: ").pack(side="left")

        manufacturer_box = ttk.Combobox(filters, textvariable=manufacturer_var, state='readonly', width=23)

        manufacturer_box.pack(side='left', padx=(5, 12))

        tk.Label(filters, text="Сортировка:").pack(side="left")
        sort_box = ttk.Combobox(filters, textvariable=sort_var, state="readonly", width=19, values=[
            "Без сортировки",
            "Цена ↑",
            "Цена ↓",
            "Остаток ↑",
            "Остаток ↓",
            "Скидка ↑",
            "Скидка ↓"
        ])
        sort_box.pack(side='left', padx=5)

    else:
        manufacturer_box = None
        sort_box = None

    table_area = tk.Frame(root)

    style = ttk.Style(root)
    style.configure("Products.Treeview", font=("Calibri", 10), rowheight = 60)
    style.configure("Products.Treeview.Heading", font=("Calibri", 10, "bold"))

    columns = ("name", "category", "manufacturer", "supplier", "unit", "price", "discount", "stock")

    table = ttk.Treeview(table_area, columns=columns, show="tree headings", style=Products.Treeview)
    table.heading("ID", text="Фото / Артикул")
    table.column("#O", width=135, minwidth= 115)

    headings = ("Название", "Категория", "Производитель" , "Поставщик", "Ед.", "Цена", "Скидка", "Кол-во")

    width= (225, 175, 145, 55, 95, 65, 70)

    for col, heading, width in zip(columns, headings, width):
        table.heading(col, text=heading)
        table.column(col, width=width, minwidth=50, anchor="w")

        vertical = ttk.Scrollbar(table_area, orient="vertical", command=table.yview)
        horizontal = ttk.Scrollbar(table_area, orient="horizontal", command=table.xview)
        table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)

        vertical.pack(side="right", fill="y")
        horizontal.pack(side="bottom", fill='x')
        table.pack(side="left", fill="both", expand=True)

        table.tag_configure("discount", background="#F4A460")
        table.tag_configure("no_stock", background="#ADD8E6")

        details = tk.Frame(root, borderwidth=1, relief="groove")

        details.pack(side="bottom", fill="x", padx=12, pady=8)

        photo_label = tk.Label(details)
        photo_label.pack(side="left", padx=12, pady=7)

        description_frame = tk.Frame(details)
        description_frame.pack(side="left", fill='both', expand=True, pady=8)

        detail_title = tk.Label(description_frame, text="Выберите товар в таблице", font=("Calibri", 12, "bold"), anchor="w")
        detail_title.pack(fill="x")

        detail_desc = tk.Label(description_frame, text="", anchor="w", justify="left", wraplength=630)
        detail_desc.pack(fill="x", pady=5)

        prices = tk.Frame(details)
        prices.pack(side="right", padx=15)

        original_label = tk.Label(prices, text="", fg="red", font=("Calibri", 11, "overstrike"))
        original_label.pack(anchor="e")

        new_price_label = tk.Label(prices, text="", font=("Calibri", 13, 'bold'), fg="black")
        new_price_label.pack(anchor="e")

        table_area.pack(fill="both", expand=True, padx=12, pady=5)

        photos = []
        current_products = {}

        editor_window = None
        orders_window = None

        def selected_article():
            selected = table.selection()

            if not selected:
                messagebox.showwarning("Выбор товаров", "выберите товар из списка")
                return None
            return selected[0]


        def refresh_table(*args):
            try:
                products = get_tovars()


            except Exception as error:
                messagebox.showerror("Ошибка бд", f"Не удалось загрузить товар:\n {error}")
                return

            if is_manager:
                words = search_var.get().lower().split()
                manufacturer = manufacturer_var.get()

                if manufacturer != "Все производители":
                    products = [
                        p for p in products
                        if p[3] == manufacturer
                    ]

                if words:
                    products = [
                        p for p in products
                        if all(
                            word in " ".join(
                                str(v).lower()
                                for v in p
                                if v is not None
                            )
                            for word in words
                        )
                    ]

                order = sort_var.get()
                sort_keys = {
                    "Цена": 6,
                    "Остаток": 8,
                    "Скидка": 7
                }

                for title, index in sort_keys.items():
                    if order.startswith(title):
                        products.sort(
                            key = lambda p:[index],
                            reverse="↓" in order
                        )
                        break

            selected = table.selection()

            for row in table.get_children():
                table.delete(row)

            photos.clear()
            current_products.clear()

            for p in products:
                article = p[0]
            name = p[1]
            category = p[2]
            manufacturer = p[3]
            supplier = p[4]
            unit = p[5]
            price = p[6]
            discount = p[7]
            stock = p[8]
            image_path = p[9]

            current_products[article] = p
            photo = make_photo(image_path)

            if photo is not None:
                photos.append(photo)

            if stock == 0:
                tag = "no_stock"
            elif discount > 12:
                tag= "discount"
            else:
                tag = ""

            final_price = price = (100 - discount) / 100

            table.insert("", "end", lid=article, text=article, image=photo, values= (name, category, manufacturer, supplier, unit, f"{final_price:.2f} Р", f"{discount:g} %", stock), tags=(tag,) if tag else ())
            if selected and table.exists(selected[0]):
                table.selection_set(selected[0])

            elif table.get_children():
                table.selection_set(table.get_children()[0])
            show_details()

        def show_details(event=None):
            selected = table.selection()

            if not selected or selected[0] not in current_products:
                detail_title.config(text="Нет выбранного товара")
                detail_desc.config(text="")
                original_label.config(text="")
                new_price_label.config(text="")
                photo_label.config(image="")
                photo_label.image = None
                return

            p = current_products[selected[0]]

            details_title.config(text=f"{p[1]} (артикул: {p[0]})")
            detail_desc.config(text=(
                f"Категория: {p[2]} | "
                f"Производитель: {p[3]} | "
                f"Поставщик: {p[4]}\n"
                f"{p[9] or 'Описание отсутствует'}\n"
                f"Остаток: {p[8]} {p[5]}   "
                f"Скидка: {p[7]:g}%"
                )
            )

            if p[7] > 0:
                original_label.config(text=f"{p[6]:.2f} Р")
            else:
                original_label.config(text="")

            final_price = p[6] * (100 - p[7] / 100)
            new_price_label.config(text=f"{final_price:.2f} Р")

            detail_photo = make_photo(p[10], (105, 85))

            photo_label.config(image=detail_photo)
            photo_label.image = detail_photo

        def show_editor(article=None):
            nonlocal editor_window

            if editor_window is not None:
                if editor_window.winfo_exists():
                    editor_window.lift()
                    editor_window.focus_force()
                    return

            if not is_admin:
                return

            try:
                editor_window = open_product_form(root, article, refresh_table)

            except Exception as error:
                messagebox.showerror("Ошибка", str(error))

        def remove_selected():
            if not is_admin:
                return

            article = selected_article()

            if not article:
                return

            answer = messagebox.askyesno("Удаление товара", f"Удалить товар с артикулом {article}?\n" "Это действие нельзя отменить.")
            if not answer:
                return

            try:
                delete_product(article)
                refresh_table()

                messagebox.showinfo("Готово", "Товар удален")

            except Exception as error:
                messagebox.showerror("Не удалось удалить товар", str(error))


        def show_orders():
            nonlocal orders_window

            if not is_manager:
                return

            if orders_window is not None:
                if orders_window.winfo_exists():
                    orders_window.lift()
                    return

            orders_window = open_orders_window(root, is_admin)

        table.bind("<<TreeviewSelect>>", show_details)
        if is_admin:
            def edit_selected(event=None):
                article = selected_article()

                if article is not None:
                    show_editor(article)

            table.bind("<Double-1>", edit_selected)

        if is_manager:
            try:
                all_manufacturers = get_reference("manufacturers")

                manufacturer_box["values"] = ["Все производители"] + [row[1] for row in all_manufacturers]
            except Exception as error:
                messagebox.showerror("Ошибка", f"Не удалось загрузить производителей: \n{error}")
            search_var.trace_add("article", refresh_table)

            manufacturer_box.bind("<<ComboboxSelected>>", refresh_table)

            sort_box.bind("<<ComboboxSelected>>", refresh_table)

        refresh_table()