import customtkinter as ctk
from customtkinter import *

window = ctk.CTk()
window.title("Анкета пользователя")
window.geometry("1080x760")

entry_name = ctk.CTkEntry(window, placeholder_text="Введите ваше имя", width=400)
entry_name.pack(pady=8)

entry_age = ctk.CTkEntry(window,placeholder_text="Введите ваш возраст", width=400)
entry_age.pack(pady=8)

entry_city = ctk.CTkEntry(window, placeholder_text="Введите ваш город", width=400)
entry_city.pack(pady=8)

result_label = ctk.CTkLabel(window, text="", font=("Arial", 16), wraplength=400)
result_label.pack(pady=8)


def info():
    name = entry_name.get().strip()
    age = entry_age.get().strip()
    city = entry_city.get().strip()

    if not name or not age or not city:
        result_label.configure(text="Заполните все поля", text_color="red")
        return

    if not age.isdigit():
        result_label.configure(text="Возраст должен быть числом", text_color="red")
        return

    age_number = int(age)
    if not 1 <= age_number <= 120:
        result_label.configure(text="Введите корректный возраст", text_color="red")
        return
    result_label.configure(text=f"Ваше имя: {name}\nВозраст:{age}\nГород:{city}", text_color="green")

btn1 = ctk.CTkButton(window, text="Показать информацию", command=info)
btn1.pack(pady=(20,8))

def clear_entries():
    entry_name.delete(0, "end")
    entry_age.delete(0, "end")
    entry_city.delete(0, "end")

btn2 = ctk.CTkButton(window, text="Очистить", command=clear_entries)
btn2.pack(pady=8)

def exit():
    window.destroy()

btn3 = ctk.CTkButton(window, text="Выход", command=exit)
btn3.pack(pady=8)

window.mainloop()