"""Быстрая проверка подключения, базы, таблиц и количества данных."""
from tkinter import Tk, messagebox
import database

def main():
    try:
        check = database.fetch_one('SELECT DATABASE() AS name')
        print('Подключение к базе:', check['name'])
        for table in ('roles','users','products','orders','order_items'):
            value = database.fetch_one(f'SELECT COUNT(*) AS number FROM {table}')
            print(f'{table}: {value["number"]} записей')
        print('OK — подключение и ключевые таблицы доступны.')
    except Exception as exc:
        print('ОШИБКА ПОДКЛЮЧЕНИЯ:', exc)
        print('Проверьте settings.ini, службу MySQL и выполнен ли sql/stroymaterialy_exam_db.sql.')
        raise SystemExit(1)

if __name__ == '__main__':
    main()
