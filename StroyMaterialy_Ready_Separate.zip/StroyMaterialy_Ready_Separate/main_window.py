"""Прокручиваемый каталог с фотографиями, правами и поиском в реальном времени."""
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
import database
from config import resource_path
from logic import (WHITE, GOLD, DARK_GOLD, final_price, money_text,
                   product_background, filter_and_sort)
from ui_common import logo, show_error

SORTS = ('По умолчанию', 'Цена: по возрастанию', 'Цена: по убыванию',
         'Остаток: по возрастанию', 'Остаток: по убыванию',
         'Скидка: по возрастанию', 'Скидка: по убыванию')


class Catalog:
    def __init__(self, app, user):
        self.app, self.user = app, user
        self.role = user['role'] if user else 'Гость'
        self.staff = self.role in ('Менеджер', 'Администратор')
        self.admin = self.role == 'Администратор'
        self.photos = []
        self.products = []
        self.search = tk.StringVar()
        self.manufacturer = tk.StringVar(value='Все производители')
        self.sort = tk.StringVar(value='По умолчанию')
        self._create_ui()
        self.reload()

    def _create_ui(self):
        header = tk.Frame(self.app, bg=GOLD, height=92)
        header.pack(fill='x')
        header.pack_propagate(False)
        logo(header, 165, 69).pack(side='left', padx=18)
        tk.Label(header, text='КАТАЛОГ ТОВАРОВ', font=('Calibri', 19, 'bold'), bg=GOLD,
                 fg='#2B220D').pack(side='left', padx=15)
        right = tk.Frame(header, bg=GOLD)
        right.pack(side='right', padx=20)
        tk.Label(right, text=self.user['full_name'] if self.user else 'Гость',
                 font=('Calibri', 12, 'bold'), bg=GOLD).pack(anchor='e')
        tk.Label(right, text=self.role, bg=GOLD).pack(anchor='e')
        ttk.Button(right, text='Выйти', command=self.app.show_login).pack(anchor='e', pady=3)

        toolbar = ttk.Frame(self.app)
        toolbar.pack(fill='x', padx=17, pady=(12, 5))
        if self.staff:
            ttk.Button(toolbar, text='Заказы', command=lambda: self.app.show_orders(self.user)).pack(side='left', padx=(0, 8))
        if self.admin:
            ttk.Button(toolbar, text='+ Добавить товар', style='Accent.TButton',
                       command=lambda: self.open_product_form(None)).pack(side='left', padx=(0, 8))
        ttk.Button(toolbar, text='Обновить каталог', command=self.reload).pack(side='right')

        if self.staff:
            filters = ttk.Frame(self.app)
            filters.pack(fill='x', padx=17, pady=(4, 7))
            ttk.Label(filters, text='Поиск:').pack(side='left', padx=(0, 5))
            ttk.Entry(filters, textvariable=self.search, width=27).pack(side='left', padx=(0, 15))
            ttk.Label(filters, text='Производитель:').pack(side='left', padx=(0, 5))
            self.manufacturer_widget = ttk.Combobox(filters, textvariable=self.manufacturer,
                            state='readonly', width=20, values=('Все производители',))
            self.manufacturer_widget.pack(side='left', padx=(0, 15))
            ttk.Label(filters, text='Сортировка:').pack(side='left', padx=(0, 5))
            ttk.Combobox(filters, textvariable=self.sort, state='readonly', width=26,
                         values=SORTS).pack(side='left')
            self.search.trace_add('write', lambda *_: self.apply_filters())
            self.manufacturer.trace_add('write', lambda *_: self.apply_filters())
            self.sort.trace_add('write', lambda *_: self.apply_filters())
        self.count_label = ttk.Label(self.app, text='Загрузка каталога…')
        self.count_label.pack(anchor='w', padx=19, pady=(3, 7))

        area = ttk.Frame(self.app)
        area.pack(fill='both', expand=True, padx=17, pady=(0, 12))
        canvas = tk.Canvas(area, bg=WHITE, highlightthickness=0, borderwidth=0)
        scrollbar = ttk.Scrollbar(area, orient='vertical', command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side='right', fill='y')
        canvas.pack(side='left', fill='both', expand=True)
        content = tk.Frame(canvas, bg=WHITE)
        handle = canvas.create_window((0, 0), window=content, anchor='nw')
        content.bind('<Configure>', lambda _: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>', lambda event: canvas.itemconfigure(handle, width=event.width))
        self.canvas, self.content = canvas, content
        # Прокрутка колёсиком только при нахождении курсора над каталогом.
        def wheel(event):
            if event.delta:
                canvas.yview_scroll(-int(event.delta / 120) or (-1 if event.delta > 0 else 1), 'units')
            elif event.num in (4, 5):
                canvas.yview_scroll(-1 if event.num == 4 else 1, 'units')
        def enter(_):
            canvas.bind_all('<MouseWheel>', wheel)
            canvas.bind_all('<Button-4>', wheel)
            canvas.bind_all('<Button-5>', wheel)
        def leave(_):
            canvas.unbind_all('<MouseWheel>')
            canvas.unbind_all('<Button-4>')
            canvas.unbind_all('<Button-5>')
        area.bind('<Enter>', enter)
        area.bind('<Leave>', leave)

    def reload(self):
        try:
            self.products = database.get_products()
        except Exception as exc:
            show_error(exc, 'Не удалось загрузить каталог')
            self.products = []
        if self.staff:
            names = ['Все производители'] + sorted({p['manufacturer'] for p in self.products})
            self.manufacturer_widget.configure(values=names)
            if self.manufacturer.get() not in names:
                self.manufacturer.set('Все производители')
        self.apply_filters()

    def apply_filters(self):
        matches = filter_and_sort(self.products,
                     self.search.get() if self.staff else '',
                     self.manufacturer.get() if self.staff else 'Все производители',
                     self.sort.get() if self.staff else 'По умолчанию')
        self.count_label.configure(text=f'Найдено товаров: {len(matches)} из {len(self.products)}')
        self.photos.clear()
        for child in self.content.winfo_children():
            child.destroy()
        if not matches:
            tk.Label(self.content, text='Товары не найдены', bg=WHITE, fg='#666',
                     font=('Calibri', 15)).pack(pady=35)
        for product in matches:
            self._card(product)
        self.canvas.yview_moveto(0)

    def _image(self, image_path):
        path = resource_path(image_path)
        try:
            with Image.open(path) as img:
                copy = img.copy()
                copy.thumbnail((112, 94), Image.Resampling.LANCZOS)
                return ImageTk.PhotoImage(copy)
        except (OSError, ValueError):
            try:
                with Image.open(resource_path(None)) as img:
                    copy = img.copy()
                    copy.thumbnail((112, 94), Image.Resampling.LANCZOS)
                    return ImageTk.PhotoImage(copy)
            except (OSError, ValueError):
                return None

    def _card(self, product):
        bg = product_background(product['stock_quantity'], product['discount'])
        border = tk.Frame(self.content, bg='#BCB5A8', padx=1, pady=1)
        border.pack(fill='x', padx=5, pady=5)
        card = tk.Frame(border, bg=bg, padx=12, pady=11)
        card.pack(fill='x')
        image = self._image(product['image_path'])
        img_box = tk.Frame(card, bg=bg, width=128, height=108)
        img_box.pack(side='left', padx=(0, 14))
        img_box.pack_propagate(False)
        if image is not None:
            self.photos.append(image)
            tk.Label(img_box, image=image, bg=bg).pack(expand=True)
        else:
            tk.Label(img_box, text='Нет фото', bg=bg, fg='#777').pack(expand=True)

        actions = tk.Frame(card, bg=bg)
        actions.pack(side='right', padx=(12, 2), anchor='n')
        tk.Label(actions, text=f"Скидка {product['discount']}%", bg=bg, fg='#624008',
                 font=('Calibri', 11, 'bold')).pack(anchor='e', pady=(0, 5))
        if float(product['discount']) > 0:
            tk.Label(actions, text=money_text(product['price']), fg='#B52A28', bg=bg,
                     font=('Calibri', 12, 'overstrike')).pack(anchor='e')
        tk.Label(actions, text=money_text(final_price(product['price'], product['discount'])),
                 fg='#111111', bg=bg, font=('Calibri', 16, 'bold')).pack(anchor='e')
        if self.admin:
            ttk.Button(actions, text='Изменить', command=lambda pid=product['product_id']:
                       self.open_product_form(pid)).pack(fill='x', pady=(8, 2))
            ttk.Button(actions, text='Удалить', command=lambda pid=product['product_id']:
                       self.delete_product(pid)).pack(fill='x')

        info = tk.Frame(card, bg=bg)
        info.pack(side='left', fill='both', expand=True)
        name = tk.Label(info, text=product['name'], anchor='w', justify='left', bg=bg,
                     font=('Calibri', 13, 'bold'), wraplength=430)
        name.pack(fill='x')
        self._line(info, bg, f"Артикул: {product['article']} · Категория: {product['category']}")
        self._line(info, bg, f"Производитель: {product['manufacturer']} · Поставщик: {product['supplier']}")
        self._line(info, bg, f"Остаток: {product['stock_quantity']} {product['unit']}")
        desc = product.get('description') or 'Нет описания'
        self._line(info, bg, f'Описание: {desc}', wraplength=500)

    @staticmethod
    def _line(parent, color, content, wraplength=0):
        tk.Label(parent, text=content, bg=color, fg='#383838', anchor='w', justify='left',
                 wraplength=wraplength, font=('Calibri', 10)).pack(fill='x', pady=1)

    def open_product_form(self, product_id):
        if not self.admin:
            messagebox.showwarning('Доступ запрещён', 'Изменение товаров доступно только администратору.')
            return
        if self.app.editor and self.app.editor.winfo_exists():
            self.app.editor.lift()
            self.app.editor.focus_force()
            return
        from product_form import ProductForm
        try:
            self.app.editor = ProductForm(self.app, product_id, self.reload)
        except Exception as exc:
            self.app.editor = None
            show_error(exc, 'Не удалось открыть форму товара')

    def delete_product(self, product_id):
        if not self.admin:
            messagebox.showwarning('Доступ запрещён', 'Недостаточно прав.')
            return
        product = next((p for p in self.products if p['product_id'] == product_id), None)
        if not product:
            return
        if not messagebox.askyesno('Удаление товара',
                f"Удалить «{product['name']}» (артикул {product['article']})?\nОперацию нельзя отменить."):
            return
        try:
            database.delete_product(product_id)
            self.reload()
            messagebox.showinfo('Удаление выполнено', 'Товар удалён из каталога.')
        except Exception as exc:
            show_error(exc, 'Не удалось удалить товар')
