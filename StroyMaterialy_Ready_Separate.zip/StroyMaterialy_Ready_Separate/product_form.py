"""Модальная форма добавления и редактирования товара (только администратор)."""
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from pathlib import Path
from uuid import uuid4
from PIL import Image, ImageOps, ImageTk
import database
from config import PRODUCT_IMAGE_DIR, resource_path
from logic import as_decimal, as_money, as_count, GOLD
from ui_common import modal, show_error


class ProductForm(tk.Toplevel):
    TABLE_NAMES = {'categories': 'Категория', 'manufacturers': 'Производитель',
                   'suppliers': 'Поставщик', 'units': 'Единица измерения'}
    FIELD_IDS = {'categories': 'category_id', 'manufacturers': 'manufacturer_id',
                 'suppliers': 'supplier_id', 'units': 'unit_id'}

    def __init__(self, parent, product_id, refresh):
        super().__init__(parent)
        self.parent, self.product_id, self.refresh = parent, product_id, refresh
        self.title('Добавление товара' if product_id is None else f'Редактирование товара № {product_id}')
        self.geometry('770x750')
        self.minsize(700, 670)
        self.configure(bg='white')
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.saved_file = None
        self.image_source = None
        self.references = database.product_references()
        self.current = database.get_product(product_id) if product_id is not None else None
        if product_id and not self.current:
            self.destroy()
            raise ValueError('Товар не найден. Обновите каталог.')
        self.vars = {}
        self.combo_vars = {}
        self._create_ui()
        modal(self, parent)

    def _create_ui(self):
        header = tk.Frame(self, bg=GOLD)
        header.pack(fill='x')
        tk.Label(header, text='ДОБАВИТЬ ТОВАР' if self.product_id is None else 'РЕДАКТИРОВАТЬ ТОВАР',
                 bg=GOLD, font=('Calibri', 19, 'bold')).pack(anchor='w', padx=20, pady=13)
        form = ttk.Frame(self)
        form.pack(fill='both', expand=True, padx=22, pady=12)
        form.columnconfigure(1, weight=1)
        row = 0
        if self.product_id is not None:
            ttk.Label(form, text='ID товара:').grid(row=row, column=0, sticky='w', pady=5)
            ttk.Label(form, text=str(self.product_id)).grid(row=row, column=1, sticky='w', pady=5)
            row += 1
            ttk.Label(form, text='Артикул:').grid(row=row, column=0, sticky='w', pady=5)
            ttk.Label(form, text=self.current['article']).grid(row=row, column=1, sticky='w', pady=5)
            row += 1

        row = self._input(form, row, 'Название *', 'name')
        for table, display in self.TABLE_NAMES.items():
            ttk.Label(form, text=f'{display} *:').grid(row=row, column=0, sticky='w', pady=5, padx=(0,15))
            options = self.references[table]
            var = tk.StringVar()
            combo = ttk.Combobox(form, textvariable=var, state='readonly',
                                 values=[record['name'] for record in options])
            combo.grid(row=row, column=1, sticky='ew', pady=5)
            if self.current:
                lookup = next((item['name'] for item in options
                               if item['id'] == self.current[self.FIELD_IDS[table]]), '')
                var.set(lookup)
            elif options:
                combo.current(0)
            self.combo_vars[table] = var
            row += 1
        row = self._input(form, row, 'Цена, руб. *', 'price', default='0.00')
        row = self._input(form, row, 'Скидка, % *', 'discount', default='0')
        row = self._input(form, row, 'Количество на складе *', 'stock_quantity', default='0')
        ttk.Label(form, text='Описание:').grid(row=row, column=0, sticky='nw', pady=7)
        self.description = tk.Text(form, height=4, wrap='word', font=('Calibri', 11))
        self.description.grid(row=row, column=1, sticky='ew', pady=5)
        if self.current and self.current.get('description'):
            self.description.insert('1.0', self.current['description'])
        row += 1
        ttk.Label(form, text='Фото товара:').grid(row=row, column=0, sticky='nw', pady=6)
        image_bar = ttk.Frame(form)
        image_bar.grid(row=row, column=1, sticky='w', pady=7)
        ttk.Button(image_bar, text='Выбрать изображение…', command=self.choose_image).pack(side='left')
        self.image_caption = ttk.Label(image_bar, text='Нет файла')
        self.image_caption.pack(side='left', padx=12)
        row += 1
        self.preview = ttk.Label(form, text='')
        self.preview.grid(row=row, column=1, sticky='w', pady=8)
        if self.current and self.current.get('image_path'):
            self.show_preview(resource_path(self.current['image_path']))
        else:
            self.show_preview(resource_path(None))
        controls = ttk.Frame(self)
        controls.pack(fill='x', padx=22, pady=(0, 20))
        ttk.Button(controls, text='Сохранить', style='Accent.TButton', command=self.save).pack(side='right', padx=(8,0))
        ttk.Button(controls, text='Отмена', command=self.close).pack(side='right')

    def _input(self, parent, row, label, field, default=''):
        ttk.Label(parent, text=label+':').grid(row=row, column=0, sticky='w', pady=5, padx=(0, 15))
        initial = self.current[field] if self.current else default
        value = tk.StringVar(value=str(initial if initial is not None else ''))
        ttk.Entry(parent, textvariable=value).grid(row=row, column=1, sticky='ew', pady=5)
        self.vars[field] = value
        return row + 1

    def choose_image(self):
        chosen = filedialog.askopenfilename(parent=self, title='Выберите изображение товара',
                     filetypes=[('Изображения', '*.png *.jpg *.jpeg *.bmp *.webp'), ('Все файлы', '*.*')])
        if not chosen:
            return
        try:
            with Image.open(chosen) as test:
                test.verify()
        except (OSError, ValueError) as exc:
            messagebox.showerror('Ошибка изображения', f'Выбранный файл не удалось открыть: {exc}', parent=self)
            return
        self.image_source = Path(chosen)
        self.show_preview(self.image_source)

    def show_preview(self, path):
        self.image_caption.configure(text=path.name)
        try:
            with Image.open(path) as img:
                copy = img.copy()
                copy.thumbnail((150, 90), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(copy)
            self.preview.configure(image=photo, text='')
            self.preview.image = photo
        except (OSError, ValueError):
            self.preview.configure(image='', text='Изображение недоступно')
            self.preview.image = None

    def save(self):
        try:
            name = self.vars['name'].get().strip()
            if not name or len(name) > 255:
                raise ValueError('Название обязательно и не должно превышать 255 символов.')
            data = {'name': name,
                    'price': as_money(self.vars['price'].get()),
                    'discount': as_decimal(self.vars['discount'].get(), 'Скидка', 100),
                    'stock_quantity': as_count(self.vars['stock_quantity'].get()),
                    'description': self.description.get('1.0', 'end-1c').strip() or None,
                    'image_path': self.current['image_path'] if self.current else None}
            for table, var in self.combo_vars.items():
                selected = next((i['id'] for i in self.references[table]
                                 if i['name'] == var.get()), None)
                if selected is None:
                    raise ValueError(f'Выберите поле «{self.TABLE_NAMES[table]}».')
                data[self.FIELD_IDS[table]] = selected
            if self.image_source:
                PRODUCT_IMAGE_DIR.mkdir(parents=True, exist_ok=True)
                dest = PRODUCT_IMAGE_DIR / (uuid4().hex + '.png')
                with Image.open(self.image_source) as original:
                    image = ImageOps.exif_transpose(original).convert('RGB')
                    image.thumbnail((300, 200), Image.Resampling.LANCZOS)
                    image.save(dest, 'PNG')
                self.saved_file = dest
                data['image_path'] = f'resources/products/{dest.name}'
            old = self.current['image_path'] if self.current else None
            new_id = database.save_product(data, self.product_id)
            self.saved_file = None
            if old and old != data['image_path']:
                database.maybe_delete_unused_image(old)
            self.refresh()
            messagebox.showinfo('Сохранено', f'Товар № {new_id} успешно сохранён.', parent=self)
            self.close()
        except Exception as exc:
            if self.saved_file:
                self.saved_file.unlink(missing_ok=True)
                self.saved_file = None
            show_error(exc, 'Товар не сохранён')

    def close(self):
        self.parent.editor = None
        self.destroy()
