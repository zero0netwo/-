"""Вся работа с MySQL изолирована от интерфейса."""
from contextlib import contextmanager
from pathlib import Path
from uuid import uuid4
import mysql.connector
from config import DB_CONFIG, PRODUCT_IMAGE_DIR, APP_DIR


@contextmanager
def transaction():
    con = mysql.connector.connect(**DB_CONFIG)
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


def fetch_all(query, params=()):
    with transaction() as con:
        cursor = con.cursor(dictionary=True)
        try:
            cursor.execute(query, params)
            return cursor.fetchall()
        finally:
            cursor.close()


def fetch_one(query, params=()):
    rows = fetch_all(query, params)
    return rows[0] if rows else None


def get_user(login, password):
    # Пароли без хеширования сохранены в учебном наборе ДЭ; не применять в продакшене.
    return fetch_one('''SELECT u.user_id, u.full_name, u.login, r.name AS role
        FROM users u JOIN roles r ON r.role_id = u.role_id
        WHERE u.login=%s AND u.password=%s''', (login, password))


PRODUCT_SELECT = '''
SELECT p.product_id, p.article, p.name, p.category_id, p.manufacturer_id,
       p.supplier_id, p.unit_id, p.price, p.discount, p.stock_quantity,
       p.description, p.image_path,
       c.name AS category, m.name AS manufacturer, s.name AS supplier,
       u.name AS unit
FROM products p
JOIN categories c ON c.category_id=p.category_id
JOIN manufacturers m ON m.manufacturer_id=p.manufacturer_id
JOIN suppliers s ON s.supplier_id=p.supplier_id
JOIN units u ON u.unit_id=p.unit_id
'''


def get_products():
    return fetch_all(PRODUCT_SELECT + ' ORDER BY p.product_id')


def get_product(product_id):
    return fetch_one(PRODUCT_SELECT + ' WHERE p.product_id=%s', (product_id,))


def product_references():
    schemas = [('categories','category_id'), ('manufacturers','manufacturer_id'),
               ('suppliers','supplier_id'), ('units','unit_id')]
    return {table: fetch_all(f'SELECT {pk} AS id, name FROM {table} ORDER BY name')
            for table, pk in schemas}


def save_product(data, product_id=None):
    fields = ('name', 'category_id', 'manufacturer_id', 'supplier_id', 'unit_id',
              'price', 'discount', 'stock_quantity', 'description', 'image_path')
    values = tuple(data[f] for f in fields)
    with transaction() as con:
        cur = con.cursor()
        try:
            if product_id is None:
                cur.execute(f'''INSERT INTO products (article, {', '.join(fields)})
                      VALUES ({', '.join(['%s']*(len(fields)+1))})''',
                            (f'TMP{uuid4().hex[:12]}', *values))
                product_id = cur.lastrowid
                cur.execute('UPDATE products SET article=%s WHERE product_id=%s',
                            (f'PRD{product_id}', product_id))
            else:
                cur.execute('UPDATE products SET ' + ', '.join(f'{f}=%s' for f in fields) +
                            ' WHERE product_id=%s', (*values, product_id))
                if cur.rowcount == 0:
                    # В MySQL rowcount=0 может означать идентичные значения; существование проверяем отдельно.
                    cur.execute('SELECT product_id FROM products WHERE product_id=%s', (product_id,))
                    if cur.fetchone() is None:
                        raise ValueError('Товар удалён другим пользователем. Обновите каталог.')
        finally:
            cur.close()
    return product_id


def delete_product(product_id):
    with transaction() as con:
        cur = con.cursor(dictionary=True)
        try:
            cur.execute('SELECT COUNT(*) AS cnt FROM order_items WHERE product_id=%s', (product_id,))
            if cur.fetchone()['cnt']:
                raise ValueError('Товар присутствует в заказе и не может быть удалён.')
            cur.execute('SELECT image_path FROM products WHERE product_id=%s', (product_id,))
            row = cur.fetchone()
            if row is None:
                raise ValueError('Товар уже удалён. Обновите список.')
            old_path = row['image_path']
            cur.execute('DELETE FROM products WHERE product_id=%s', (product_id,))
        finally:
            cur.close()
    maybe_delete_unused_image(old_path)


def maybe_delete_unused_image(db_image_path):
    """Удаляем лишь уникальные изображения внутри ресурсов и лишь после успешного SQL."""
    if not db_image_path:
        return
    normalized = str(db_image_path).replace('\\', '/')
    if not normalized.startswith('resources/products/'):
        return
    rel = Path(normalized).parts
    target = (APP_DIR / Path(*rel)).resolve()
    image_root = PRODUCT_IMAGE_DIR.resolve()
    if not target.is_relative_to(image_root) or not target.is_file():
        return
    try:
        still_used = fetch_one('SELECT COUNT(*) AS n FROM products WHERE image_path=%s', (db_image_path,))
        if still_used and still_used['n'] == 0:
            target.unlink(missing_ok=True)
    except (OSError, mysql.connector.Error):
        # Ошибка очистки не отменяет успешную транзакцию изменения записи.
        pass


def order_references():
    return {
        'clients': fetch_all('''SELECT u.user_id AS id, CONCAT(u.full_name,' — ',u.login) AS name
             FROM users u JOIN roles r ON u.role_id=r.role_id
             WHERE r.name='Клиент' ORDER BY u.full_name'''),
        'points': fetch_all('SELECT pickup_point_id AS id, address AS name FROM pickup_points ORDER BY pickup_point_id'),
        'statuses': fetch_all('SELECT status_id AS id, name FROM order_statuses ORDER BY status_id'),
        'products': fetch_all('SELECT product_id AS id, CONCAT(article," — ",name) AS name, article FROM products ORDER BY article'),
    }


def get_orders():
    return fetch_all('''
    SELECT o.order_id, o.client_id, o.pickup_point_id, o.status_id,
           o.order_date, o.delivery_date, o.receive_code,
           u.full_name AS client_name, pp.address, os.name AS status,
           GROUP_CONCAT(CONCAT(p.article,' × ',oi.quantity) ORDER BY p.article SEPARATOR ', ') AS articles
    FROM orders o
    JOIN users u ON u.user_id=o.client_id
    JOIN pickup_points pp ON pp.pickup_point_id=o.pickup_point_id
    JOIN order_statuses os ON os.status_id=o.status_id
    LEFT JOIN order_items oi ON oi.order_id=o.order_id
    LEFT JOIN products p ON p.product_id=oi.product_id
    GROUP BY o.order_id, o.client_id, o.pickup_point_id, o.status_id,
             o.order_date, o.delivery_date, o.receive_code,
             u.full_name, pp.address, os.name
    ORDER BY o.order_id DESC''')


def get_order(order_id):
    header = fetch_one('SELECT * FROM orders WHERE order_id=%s', (order_id,))
    if not header:
        return None
    header['items'] = fetch_all('''SELECT oi.product_id, oi.quantity, p.article, p.name
            FROM order_items oi JOIN products p ON p.product_id=oi.product_id
            WHERE oi.order_id=%s ORDER BY p.article''', (order_id,))
    return header


def save_order(data, items, order_id=None):
    if not items:
        raise ValueError('Добавьте хотя бы один товар в заказ.')
    with transaction() as con:
        cur = con.cursor()
        try:
            if order_id is None:
                cur.execute('''INSERT INTO orders
                      (client_id, pickup_point_id, status_id, order_date, delivery_date, receive_code)
                      VALUES (%s,%s,%s,%s,%s,%s)''',
                    (data['client_id'],data['pickup_point_id'],data['status_id'],
                     data['order_date'],data['delivery_date'],'TEMP'))
                order_id = cur.lastrowid
                cur.execute('UPDATE orders SET receive_code=%s WHERE order_id=%s',
                            (str(9000+order_id), order_id))
            else:
                cur.execute('''UPDATE orders SET client_id=%s, pickup_point_id=%s,
                       status_id=%s, order_date=%s, delivery_date=%s WHERE order_id=%s''',
                    (data['client_id'],data['pickup_point_id'],data['status_id'],
                     data['order_date'],data['delivery_date'],order_id))
                if cur.rowcount == 0:
                    cur.execute('SELECT order_id FROM orders WHERE order_id=%s', (order_id,))
                    if cur.fetchone() is None:
                        raise ValueError('Заказ не найден. Обновите список.')
                cur.execute('DELETE FROM order_items WHERE order_id=%s', (order_id,))
            cur.executemany('INSERT INTO order_items (order_id, product_id, quantity) VALUES (%s,%s,%s)',
                            [(order_id, i['product_id'],i['quantity']) for i in items])
        finally:
            cur.close()
    return order_id


def delete_order(order_id):
    with transaction() as con:
        cur = con.cursor()
        try:
            cur.execute('DELETE FROM orders WHERE order_id=%s', (order_id,))
            if cur.rowcount == 0:
                raise ValueError('Заказ не найден. Обновите список.')
        finally:
            cur.close()
