import customtkinter as ctk

window = ctk.CTk()
window.title("Калькулятор")
window.geometry("750x450")

entry_value1 = ctk.CTkEntry(window, placeholder_text="Введите первое число", width=400)
entry_value1.pack(pady=8)

entry_value2 = ctk.CTkEntry(window, placeholder_text="Введите второе число", width=400)
entry_value2.pack(pady=8)

operation_entry = ctk.CTkEntry(window, placeholder_text="Выберите операцию: +, -, *, /")
operation_entry.pack(pady=8)

result_label = ctk.CTkLabel(window, text="")
result_label.pack(pady=8)

def get_value():
    str_v1 = entry_value1.get().strip()
    str_v2 = entry_value2.get().strip()
    operation = operation_entry.get().strip()

    try:
        value1 = float(str_v1.replace(",", "."))
        value2 = float(str_v2.replace(",", "."))
    except ValueError:
        result_label.configure(text="Ошибка: введите корректные числа")
        return

    if operation == "+":
        result = value1 + value2
    elif operation == "-":
        result = value1 - value2
    elif operation == "*":
        result = value1 * value2
    elif operation == "/":
        if value2 == 0:
            result_label.configure(text="Ошибка: деление на ноль!")
            return
        result = value1 / value2
    else:
        result_label.configure(text="Ошибка: неверная операция (+, -, *, /)")
        return

    result_label.configure(text=f"Результат: {result}")

btn_result = ctk.CTkButton(window, text="Посчитать", command=get_value)
btn_result.pack(pady=8)

window.mainloop()