
import customtkinter as ctk

window4 = ctk.CTk()
window4.title("Окно задания 4")
window4.geometry("750x450")

text = ctk.CTkLabel(window4, text="Заполните поле")
text.pack(pady=10)

entry1 = ctk.CTkEntry(
    window4,
    width=400,
    placeholder_text="Введите текст"
)
entry1.pack(pady=30)


def click_first():
    input_entry = entry1.get()
    text.configure(text=f"Было введено: {input_entry}")


def click_second():
    entry1.delete(0, "end")
    text.configure(text="Заполните поле")


def click_third():
    entry1.delete(0, "end")
    entry1.insert(0, "Изучаю Python")
    text.configure(text="Заполните поле")


first_button = ctk.CTkButton(
    window4, text="Получить текст", command=click_first
)
first_button.pack(pady=10)

second_button = ctk.CTkButton(
    window4, text="Очистить", command=click_second
)
second_button.pack(pady=10)

third_button = ctk.CTkButton(
    window4, text="Вставить пример", command=click_third
)
third_button.pack(pady=10)

window4.mainloop()
