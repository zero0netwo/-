"""Общие элементы окон: стиль, логотип и безопасное отображение ошибок."""
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk
from config import RESOURCE_DIR
from logic import WHITE, GOLD, DARK_GOLD

FONT = ('Calibri', 11)


def setup_style(root):
    root.configure(bg=WHITE)
    root.option_add('*Font', FONT)
    s = ttk.Style(root)
    if 'clam' in s.theme_names():
        s.theme_use('clam')
    s.configure('TFrame', background=WHITE)
    s.configure('TLabel', background=WHITE, font=FONT)
    s.configure('TButton', padding=(12, 7), font=FONT)
    s.configure('Accent.TButton', background=DARK_GOLD, foreground='white', padding=(14, 8))
    s.map('Accent.TButton', background=[('active', GOLD)])
    s.configure('TEntry', padding=5)
    s.configure('TCombobox', padding=5)
    s.configure('Treeview', font=('Calibri', 10), rowheight=28)
    s.configure('Treeview.Heading', font=('Calibri', 11, 'bold'))


def clear(window):
    for child in window.winfo_children():
        child.destroy()


def logo(parent, width=160, height=65, bg=GOLD):
    frame = tk.Frame(parent, bg=bg)
    img = RESOURCE_DIR / 'icon.png'
    if img.is_file():
        try:
            with Image.open(img) as original:
                copy = original.copy()
                copy.thumbnail((width, height), Image.Resampling.LANCZOS)
                photo = ImageTk.PhotoImage(copy)
            label = tk.Label(frame, image=photo, bg=bg)
            label.image = photo
            label.pack()
            return frame
        except (OSError, ValueError):
            pass
    tk.Label(frame, text='СТРОЙМАТЕРИАЛЫ', bg=bg, fg='#30270D',
             font=('Calibri', 15, 'bold')).pack(padx=8, pady=8)
    return frame


def show_error(exc, context='Не удалось выполнить операцию'):
    detail = str(exc).strip() or type(exc).__name__
    messagebox.showerror('Ошибка', f'{context}.\n\nПричина: {detail}\n\nПроверьте введённые данные и подключение к MySQL.')


def date_text(value):
    return value.strftime('%d.%m.%Y') if value else '—'


def modal(dialog, parent):
    dialog.transient(parent)
    dialog.grab_set()
    dialog.focus_set()


def buttons_bar(parent):
    bar = ttk.Frame(parent)
    bar.pack(fill='x', padx=16, pady=(8, 12))
    return bar
