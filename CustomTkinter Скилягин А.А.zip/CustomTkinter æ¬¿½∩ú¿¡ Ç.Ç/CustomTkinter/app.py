import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

window = ctk.CTk()
window.geometry("700x450")
window.title("Лабораторная работа № 2")

content = ctk.CTkScrollableFrame(window)
content.pack(fill="both", expand=True, padx=20, pady=20)

# ззадание 1
first_label = ctk.CTkLabel(
    content,
    text="Изучение CustomTkinter",
    font=("Arial", 26, "bold"),
)
first_label.pack(pady=(10, 15))

second_label = ctk.CTkLabel(
    content,
    text="Лабораторная работа № 2",
    font=("Arial", 20),
)
second_label.pack(pady=10)

third_label = ctk.CTkLabel(
    content,
    text="Основные элементы интерфейса",
    font=("Arial", 16),
)
third_label.pack(pady=(10, 20))

# задание 2
action_label = ctk.CTkLabel(
    content, text="Выберите действие", font=("Arial", 18)
)
action_label.pack(pady=(10, 8))


def first_btn():
    action_label.configure(text="Добро пожаловать!")


def second_btn():
    window.title("Заголовок изменён")


def third_btn():
    window.destroy()


first_button = ctk.CTkButton(
    content, text="Приветствие", command=first_btn
)
first_button.pack(pady=6)

second_button = ctk.CTkButton(
    content, text="Изменить заголовок", command=second_btn
)
second_button.pack(pady=6)

third_button = ctk.CTkButton(content, text="Выход", command=third_btn)
third_button.pack(pady=6)

# задание 3
enter_name_label = ctk.CTkLabel(
    content, text="Введите ваше имя", font=("Arial", 20)
)
enter_name_label.pack(pady=(25, 8))

entry_name = ctk.CTkEntry(
    content, placeholder_text="Ваше имя", width=300
)
entry_name.pack(pady=8)

result_label = ctk.CTkLabel(content, text="", font=("Arial", 18))


def get_entry():
    name = entry_name.get().strip()
    if not name:
        result_label.configure(text="Введите ваше имя!", text_color="red")
    else:
        result_label.configure(
            text=f"Здравствуйте, {name}!", text_color="green"
        )


btn_send = ctk.CTkButton(
    content, text="Поздороваться", command=get_entry
)
btn_send.pack(pady=10)
result_label.pack(pady=(8, 20))

window.mainloop()