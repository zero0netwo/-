"""Модальная форма заказа с многопозиционным составом."""
import tkinter as tk
from tkinter import ttk, messagebox
from datetime import date
import database
from logic import GOLD, as_count, parse_date
from ui_common import modal, show_error


class OrderForm(tk.Toplevel):
    FIELDS = [('clients', 'Клиент', 'client_id'),
              ('statuses', 'Статус', 'status_id'),
              ('points', 'Пункт выдачи', 'pickup_point_id')]

    def __init__(self, parent, order_id, refresh):
        super().__init__(parent)
        self.parent, self.order_id, self.refresh = parent, order_id, refresh
        self.title('Добавление заказа' if order_id is None else f'Редактирование заказа № {order_id}')
        self.geometry('940x735')
        self.minsize(850, 650)
        self.configure(bg='white')
        self.protocol('WM_DELETE_WINDOW', self.close)
        self.refs = database.order_references()
        self.current = database.get_order(order_id) if order_id else None
        if order_id and self.current is None:
            self.destroy()
            raise ValueError('Заказ не найден.')
        self.items = {}
        if self.current:
            self.items = {i['product_id']: int(i['quantity']) for i in self.current['items']}
        self.vars = {}
        self._build()
        modal(self, parent)

    def _build(self):
        top = tk.Frame(self, bg=GOLD)
        top.pack(fill='x')
        tk.Label(top, text='ДОБАВИТЬ ЗАКАЗ' if not self.order_id else 'РЕДАКТИРОВАТЬ ЗАКАЗ',
                 bg=GOLD, font=('Calibri', 19, 'bold')).pack(side='left', padx=22, pady=14)
        if self.order_id:
            tk.Label(top, text=f'№ {self.order_id}', bg=GOLD).pack(side='right', padx=22)
        form = ttk.Frame(self)
        form.pack(fill='x', padx=24, pady=15)
        form.columnconfigure(1, weight=1)
        for row, (table, label, db_field) in enumerate(self.FIELDS):
            ttk.Label(form, text=label+':').grid(row=row, column=0, sticky='w', pady=7, padx=(0,15))
            refs = self.refs[table]
            v = tk.StringVar()
            cbo = ttk.Combobox(form, textvariable=v, state='readonly',
                  values=[item['name'] for item in refs])
            cbo.grid(row=row, column=1, sticky='ew', pady=6)
            current_id = self.current[db_field] if self.current else None
            chosen = next((x['name'] for x in refs if x['id'] == current_id), None)
            if chosen:
                v.set(chosen)
            elif refs:
                cbo.current(0)
            self.vars[table] = v
        today = date.today().isoformat()
        fields = [('Дата заказа (ГГГГ-ММ-ДД)', 'order_date', today),
                  ('Дата выдачи (ГГГГ-ММ-ДД)', 'delivery_date', today)]
        for row, (label, key, default) in enumerate(fields, start=3):
            ttk.Label(form, text=label+':').grid(row=row, column=0, sticky='w', pady=7, padx=(0,15))
            original = self.current[key] if self.current else None
            initial = original.isoformat() if original else ('' if self.current else default)
            v = tk.StringVar(value=initial)
            ttk.Entry(form, textvariable=v).grid(row=row, column=1, sticky='ew', pady=6)
            self.vars[key] = v
        ttk.Label(form, text='Код получения:').grid(row=5, column=0, sticky='w', pady=7)
        ttk.Label(form, text=str(self.current['receive_code']) if self.current else 'Будет присвоен автоматически').grid(row=5,column=1,sticky='w')

        ttk.Label(self, text='СОСТАВ ЗАКАЗА', font=('Calibri', 13, 'bold')).pack(anchor='w', padx=24, pady=(8, 5))
        choose = ttk.Frame(self)
        choose.pack(fill='x', padx=24, pady=7)
        ttk.Label(choose, text='Артикул товара:').pack(side='left', padx=(0,8))
        self.selected_product = tk.StringVar()
        self.products_by_name = {p['name']: p for p in self.refs['products']}
        self.product_combo = ttk.Combobox(choose, textvariable=self.selected_product,
             values=list(self.products_by_name), state='readonly', width=46)
        self.product_combo.pack(side='left', padx=(0,13))
        if self.products_by_name:
            self.product_combo.current(0)
        ttk.Label(choose, text='Кол-во:').pack(side='left', padx=(0,7))
        self.qty = tk.StringVar(value='1')
        ttk.Entry(choose, textvariable=self.qty, width=7).pack(side='left', padx=(0,10))
        ttk.Button(choose, text='Добавить / обновить', command=self.add_item).pack(side='left')
        columns = ('article','name','quantity')
        table_area = ttk.Frame(self)
        table_area.pack(fill='both', expand=True, padx=24, pady=9)
        self.table = ttk.Treeview(table_area, columns=columns, show='headings', height=5)
        for col, title, width in [('article','Артикул',155),('name','Товар',445),('quantity','Количество',100)]:
            self.table.heading(col, text=title)
            self.table.column(col, width=width, anchor='w')
        self.table.pack(side='left', fill='both', expand=True)
        item_scroll = ttk.Scrollbar(table_area, orient='vertical', command=self.table.yview)
        item_scroll.pack(side='right', fill='y')
        self.table.configure(yscrollcommand=item_scroll.set)
        bottom = ttk.Frame(self)
        bottom.pack(fill='x', padx=24, pady=(5,20))
        ttk.Button(bottom, text='Убрать выбранную позицию', command=self.remove_item).pack(side='left')
        ttk.Button(bottom, text='Сохранить заказ', style='Accent.TButton', command=self.save).pack(side='right', padx=(8,0))
        ttk.Button(bottom, text='Отмена', command=self.close).pack(side='right')
        self.render_items()

    def add_item(self):
        item = self.products_by_name.get(self.selected_product.get())
        if not item:
            messagebox.showwarning('Выберите товар', 'Выберите артикул товара из списка.', parent=self)
            return
        try:
            qty = as_count(self.qty.get())
            if qty == 0:
                raise ValueError('Количество должно быть больше нуля.')
        except ValueError as exc:
            messagebox.showerror('Ошибка количества', str(exc), parent=self)
            return
        self.items[item['id']] = qty
        self.render_items()

    def remove_item(self):
        selection = self.table.selection()
        if selection:
            self.items.pop(int(selection[0]), None)
            self.render_items()
        else:
            messagebox.showwarning('Выберите позицию', 'Сначала выделите строку заказа.', parent=self)

    def render_items(self):
        self.table.delete(*self.table.get_children())
        records = {p['id']: p for p in self.refs['products']}
        for pid, qty in sorted(self.items.items()):
            p = records.get(pid)
            self.table.insert('', 'end', iid=str(pid),
                   values=(p['article'] if p else '—', p['name'] if p else 'Товар удалён', qty))

    def save(self):
        try:
            fields = {}
            for table, _, db_field in self.FIELDS:
                record = next((p for p in self.refs[table] if p['name'] == self.vars[table].get()), None)
                if record is None:
                    raise ValueError(f'Выберите значение в поле «{table}».')
                fields[db_field] = record['id']
            fields['order_date'] = parse_date(self.vars['order_date'].get(), 'Дата заказа', required=not bool(self.order_id))
            fields['delivery_date'] = parse_date(self.vars['delivery_date'].get(), 'Дата выдачи')
            if fields['order_date'] and fields['delivery_date'] < fields['order_date']:
                raise ValueError('Дата выдачи не может быть раньше даты заказа.')
            if not self.items:
                raise ValueError('Добавьте хотя бы одну товарную позицию.')
            new_id = database.save_order(fields,
                    [{'product_id': pid, 'quantity': qty} for pid, qty in self.items.items()],
                    self.order_id)
            self.refresh()
            messagebox.showinfo('Заказ сохранён', f'Заказ № {new_id} успешно сохранён.', parent=self)
            self.close()
        except Exception as exc:
            show_error(exc, 'Не удалось сохранить заказ')

    def close(self):
        self.parent.editor = None
        self.destroy()
