"""Сверка исходных ссылок на изображения с комплектом ресурсов."""
import unittest
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
class ResourceTests(unittest.TestCase):
    def test_referenced_original_images_present(self):
        sql=(ROOT/'sql/stroymaterialy_exam_db.sql').read_text()
        images=set(re.findall(r"resources/products/[A-Za-z0-9]+\.(?:jpg|jpeg|png)",sql))
        self.assertEqual(len(images),10)
        self.assertTrue(all((ROOT/x).is_file() for x in images))
        self.assertTrue((ROOT/'resources/picture.png').is_file())

if __name__ == '__main__': unittest.main()
