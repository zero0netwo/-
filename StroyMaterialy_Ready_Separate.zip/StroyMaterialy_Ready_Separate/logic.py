"""Независимые от интерфейса правила отображения и валидации."""
from datetime import date
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP

ORANGE = '#F4A460'
BLUE = '#D8EDF9'
WHITE = '#FFFFFF'
GOLD = '#DAA520'
DARK_GOLD = '#B8860B'


def as_decimal(value, name, maximum=None):
    try:
        result = Decimal(str(value).strip().replace(',', '.'))
    except (ValueError, InvalidOperation):
        raise ValueError(f'Поле «{name}»: введите число.') from None
    if not result.is_finite() or result < 0:
        raise ValueError(f'Поле «{name}» не может быть отрицательным.')
    if maximum is not None and result > maximum:
        raise ValueError(f'Поле «{name}» не может превышать {maximum}.')
    return result


def as_money(value):
    money = as_decimal(value, 'Цена').quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    if money > Decimal('99999999.99'):
        raise ValueError('Цена превышает допустимый размер поля базы данных.')
    return money


def as_count(value):
    try:
        count = int(str(value).strip())
    except (TypeError, ValueError):
        raise ValueError('Количество должно быть целым числом.') from None
    if count < 0:
        raise ValueError('Количество не может быть отрицательным.')
    return count


def final_price(price, discount):
    total = Decimal(str(price)) * (Decimal('1') - Decimal(str(discount)) / Decimal('100'))
    return total.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)


def money_text(value):
    val = Decimal(str(value)).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
    return f'{val:,.2f}'.replace(',', ' ').replace('.', ',') + ' ₽'


def product_background(stock, discount):
    # Нулевой остаток имеет приоритет, если оба условия выполняются одновременно.
    return BLUE if int(stock) == 0 else ORANGE if Decimal(str(discount)) > 12 else WHITE


def filter_and_sort(products, search='', manufacturer='Все производители', sorting='По умолчанию'):
    terms = search.casefold().strip().split()
    result = []
    for product in products:
        if manufacturer != 'Все производители' and product['manufacturer'] != manufacturer:
            continue
        searchable = ' '.join(str(product.get(key) or '') for key in
            ('article', 'name', 'category', 'description', 'manufacturer', 'supplier', 'unit'))
        searchable = searchable.casefold()
        if all(term in searchable for term in terms):
            result.append(product)
    keys = {
        'Цена: по возрастанию': ('price', False),
        'Цена: по убыванию': ('price', True),
        'Остаток: по возрастанию': ('stock_quantity', False),
        'Остаток: по убыванию': ('stock_quantity', True),
        'Скидка: по возрастанию': ('discount', False),
        'Скидка: по убыванию': ('discount', True),
    }
    if sorting in keys:
        key, reverse = keys[sorting]
        return sorted(result, key=lambda p: (Decimal(str(p[key]))), reverse=reverse)
    return sorted(result, key=lambda p: p['product_id'])


def parse_date(value, title, required=True):
    raw = str(value or '').strip()
    if not raw and not required:
        return None
    if not raw:
        raise ValueError(f'Укажите {title.lower()} в формате ГГГГ-ММ-ДД.')
    try:
        return date.fromisoformat(raw)
    except ValueError:
        raise ValueError(f'«{title}»: дата должна быть реальной и записана как ГГГГ-ММ-ДД.') from None
