"""Список заказов с разграничением прав менеджера и администратора."""
import tkinter as tk
from tkinter import ttk, messagebox
import database
from logic import GOLD
from ui_common import date_text, show_error


class OrdersWindow:
    def __init__(self, app, user):
        self.app, self.user = app, user
        self.admin = user['role'] == 'Администратор'
        self._build()
        self.reload()

    def _build(self):
        head = tk.Frame(self.app, bg=GOLD, padx=22, pady=16)
        head.pack(fill='x')
        tk.Label(head, text='ЗАКАЗЫ', bg=GOLD, font=('Calibri', 21, 'bold')).pack(side='left')
        tk.Label(head, text=f"{self.user['full_name']} · {self.user['role']}",
                 bg=GOLD, font=('Calibri', 11)).pack(side='right')
        bar = ttk.Frame(self.app)
        bar.pack(fill='x', padx=20, pady=14)
        ttk.Button(bar, text='← К каталогу', command=lambda: self.app.show_catalog(self.user)).pack(side='left', padx=(0, 8))
        ttk.Button(bar, text='Обновить', command=self.reload).pack(side='left')
        ttk.Button(bar, text='Выйти', command=self.app.show_login).pack(side='right')
        if self.admin:
            ttk.Button(bar, text='+ Добавить заказ', style='Accent.TButton', command=lambda: self.edit(None)).pack(side='left', padx=10)
            ttk.Button(bar, text='Редактировать', command=self.edit_selected).pack(side='left')
            ttk.Button(bar, text='Удалить', command=self.delete_selected).pack(side='left', padx=10)
        fields = ('id','articles','status','client','address','order_date','delivery_date','code')
        body = ttk.Frame(self.app)
        body.pack(fill='both', expand=True, padx=20, pady=(0, 18))
        self.table = ttk.Treeview(body, columns=fields, show='headings', selectmode='browse')
        headers = {'id':'№','articles':'Артикулы и количество','status':'Статус',
                   'client':'Клиент','address':'Пункт выдачи',
                   'order_date':'Дата заказа','delivery_date':'Дата выдачи','code':'Код'}
        widths = {'id':55,'articles':210,'status':105,'client':175,'address':275,
                  'order_date':105,'delivery_date':105,'code':70}
        for field in fields:
            self.table.heading(field, text=headers[field])
            self.table.column(field, width=widths[field], minwidth=widths[field] // 2,
                              anchor='w', stretch=field in ('articles','address'))
        vertical = ttk.Scrollbar(body, orient='vertical', command=self.table.yview)
        horizontal = ttk.Scrollbar(body, orient='horizontal', command=self.table.xview)
        self.table.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.table.grid(row=0, column=0, sticky='nsew')
        vertical.grid(row=0, column=1, sticky='ns')
        horizontal.grid(row=1, column=0, sticky='ew')
        body.grid_columnconfigure(0, weight=1)
        body.grid_rowconfigure(0, weight=1)
        if self.admin:
            self.table.bind('<Double-1>', lambda _: self.edit_selected())
        self.status = ttk.Label(self.app, text='')
        self.status.pack(anchor='w', padx=22, pady=(0, 10))

    def reload(self):
        try:
            rows = database.get_orders()
        except Exception as exc:
            show_error(exc, 'Не удалось получить заказы')
            rows = []
        self.table.delete(*self.table.get_children())
        for row in rows:
            self.table.insert('', 'end', iid=str(row['order_id']),
              values=(row['order_id'], row['articles'] or '—', row['status'],
                      row['client_name'], row['address'], date_text(row['order_date']),
                      date_text(row['delivery_date']), row['receive_code']))
        self.status.configure(text=f'Всего заказов: {len(rows)}. Двойной щелчок для редактирования (администратор).')

    def selected(self):
        chosen = self.table.selection()
        if not chosen:
            messagebox.showwarning('Не выбран заказ', 'Выберите заказ в таблице.')
            return None
        return int(chosen[0])

    def edit_selected(self):
        selected = self.selected()
        if selected is not None:
            self.edit(selected)

    def edit(self, order_id):
        if not self.admin:
            messagebox.showwarning('Доступ запрещён', 'Менеджер может только просматривать заказы.')
            return
        if self.app.editor and self.app.editor.winfo_exists():
            self.app.editor.lift()
            return
        from order_form import OrderForm
        try:
            self.app.editor = OrderForm(self.app, order_id, self.reload)
        except Exception as exc:
            self.app.editor = None
            show_error(exc, 'Не удалось открыть форму заказа')

    def delete_selected(self):
        if not self.admin:
            messagebox.showwarning('Доступ запрещён', 'Недостаточно прав.')
            return
        selected = self.selected()
        if selected is None:
            return
        if not messagebox.askyesno('Удаление заказа', f'Удалить заказ № {selected} вместе с составом?\nОперацию нельзя отменить.'):
            return
        try:
            database.delete_order(selected)
            self.reload()
            messagebox.showinfo('Готово', 'Заказ удалён. Товары из каталога не удалялись.')
        except Exception as exc:
            show_error(exc, 'Не удалось удалить заказ')
