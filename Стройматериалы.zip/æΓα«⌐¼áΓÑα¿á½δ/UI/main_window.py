
import tkinter as tk
from tkinter import ttk
from database import get_tovars

def open_main_window(root, user, on_logout):
    for widget in root.winfo_children():
        widget.destroy()

    root.title("СтройМатериалы - Главное окно")
    root.geometry("800x500")
    root.resizable(True, True)

    if user is None:
        full_name = "Гость"
        role = "Гость"
    else:
        full_name = user[1]
        role = user[2]

    def logout():
        on_logout(root)

    header = tk.Frame(root, bg="#DAA520")
    header.pack(fill="x")

    title_label = tk.Label(
        header,
        text="СтройМатериалы",
        font=("Calibri", 16, "bold"),
        bg="#DAA520"
    )
    title_label.pack(side="left", padx=20, pady=15)

    user_label = tk.Label(
        header,
        text=full_name,
        font=("Calibri", 12),
        bg="#DAA520"
    )
    user_label.pack(side="right", padx=20)

    logout_button = tk.Button(
        header,
        text="Выйти",
        command=logout
    )
    logout_button.pack(side="right", padx=10)

    welcome_label = tk.Label(
        root,
        text="Добро пожаловать!",
        font=("Calibri", 20, "bold")
    )
    welcome_label.pack(pady=30)

    role_label = tk.Label(
        root,
        text=f"Ваша роль: {role}",
        font=("Calibri", 14)
    )
    role_label.pack(pady=10)

    info_label = tk.Label(
        root,
        text="Здесь будет отображаться каталог товаров",
        font=("Calibri", 12)
    )
    info_label.pack(pady=20)


    if role in ["Менеджер", 'Администратор']:

        columns = ("ID", "article", "name", "category_id", "manufacturer_id", "supplier_id", "unit_id", "price", "discount", "stock_quantity", "description", "image_path")

        table_products = ttk.Treeview(columns=columns, show="headings")
        vertical_scroller = ttk.Scrollbar(table_products, orient="vertical", command=table_products.yview)

        horizontal_scroller = ttk.Scrollbar(table_products, orient="horizontal", command=table_products.xview)
        table_products.configure(yscrollcommand=vertical_scroller.set, xscrollcommand=horizontal_scroller.set)

        vertical_scroller.pack(side="right", fill="y")
        horizontal_scroller.pack(side="bottom", fill="x")

        table_products.pack(side="left", fill="both", expand=True)

        table_products.heading("ID", text="ID")
        table_products.heading("article", text="Артикул")
        table_products.heading("name", text="Название товара")
        table_products.heading("category_id", text="Категория")
        table_products.heading("manufacturer_id", text="Производитель")
        table_products.heading("supplier_id", text="Поставщик")
        table_products.heading("unit_id", text="Единица измерения")
        table_products.heading("price", text="Цена")
        table_products.heading("discount", text="Скидка")
        table_products.heading("stock_quantity", text="Кол-во")

        def refresh_table(event=None):
            for item in table.get_children():
                table.delete(item)

            search_words = search_var.get().lower().split()
            selected_manufacturer = "Все производители"

            if role in ("Менеджер", "Администратор"):









