import mysql.connector
from config import DB_CONFIG


def connect_db():
    connection = mysql.connector.connect(**DB_CONFIG)

    return connection

def get_user(login, password):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT users.user_id, users.full_name, roles.name
            FROM users
            JOIN roles ON users.role_id = roles.role_id
            WHERE users.login = %s AND users.password = %s
        """

        cursor.execute(query, (login, password))
        user = cursor.fetchone()

        return user

    finally:
        cursor.close()
        connection.close()


def get_tovars():
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT
                products.article,
                products.name,
                categories.name,
                manufacturers.name,
                suppliers.name,
                units.name,
                products.price,
                products.discount,
                products.stock_quantity,
                products.description,
                products.image_path
                
                FROM products
                JOIN categories ON products.category_id = categories.category_id
                JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                JOIN suppliers ON products.supplier_id = suppliers.supplier_id
                JOIN units ON products.unit_id = units.unit_id
                ORDER BY products.product_id
                """
        cursor.execute(query)
        result = cursor.fetchall()
        return result

    finally:
        cursor.close()
        connection.close()

def get_reference(table_name):
    tables= {
        "catergories": "category_id",
        "manufacturer": "manufacturer_id",
        "suppliers": "supplier_id",
        "units": "unit_id",
        "pickup_points": "pickup_point_id",
        "order_statuses": "status_id",
        "users": "user_id"
    }

    if table_name not in tables:
        raise ValueError("Неизвестный справочник")

    key = tables[table_name]

    if table_name == "pickup_points":
        field = "address"
    elif table_name == "users":
        field = "full_name"
    else:
        field = "name"

        connection = connect_db()
        cursor = connection.cursor()

        try:
            query = f""" SELECT {key}, {field}
                FROM {table_name}
                ORDER BY {field}
            """

            cursor.execute(query)
            return cursor.fetchall()

        finally:
            cursor.close()
            connection.close()

def get_product(article):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT
                product_id,
                article,
                name,
                category_id,
                manufacturer_id,
                supplier_id,
                unit_id,
                price,
                discount,
                stock_quantity,
                description,
                image_path
            FROM products
            WHERE article = %s
            """

        cursor.execute(query, (article,))
        return cursor.fetchone()

    finally:
        cursor.close()
        connection.close()

def add_product(values):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            INSERT INTO products
            (
                article,
                name,
                category_id,
                manufacturer_id,
                supplier_id,
                unit_id,
                price,
                discount,
                stock_quantity,
                description,
                image_path
            )
            VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            
        """
        cursor.execute(query, values)
        connection.commit()

    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()

def update_product(product_id, values):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
        UPDATE products
        SET
            article = %s,
            name = %s,
            category_id = %s,
            manufacturer_id = %s,
            supplier_id = %s,
            unit_id = %s,
            price = %s,
            discount = %s,
            stock_quantity = %s,
            description = %s,
            image_path = %s
        WHERE product_id = %s
        """

        cursor.execute(query, (*values, product_id))
        connection.commit()

    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()

def delete_product(article):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        cursor.execute("SELECT product_id FROM products WHERE article = %s", (article,))
        result = cursor.fetchone()

        if result is None:
            raise ValueError("Товар не найден")

        product_id = result[0]

        cursor.execute("SELECT COUNT(*) FROM order_items WHERE product_id = %s", (product_id,))

        if cursor.fetchone()[0] > 0:
            raise ValueError("Этот товар присутствует в заказе, удалить его нельзя")
        cursor.execute("DELETE FROM products WHERE product_id = %s", (product_id,))

        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()

def get_order():
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT
                o.order_id,
                u.full_name,
                pp.address,
                s.name,
                o.order_date,
                o.delivery_date,
                o.receive_code,
                COALESCE(
                    GROUP_CONCAT(
                        CONCAT(p.article, "x" , oi.quantity)
                        ORDER BY p.article
                        SEPARATOR ','
                    ),
                    ''
                )
            FROM orders o
            JOIN users u ON u.user_id = o.client_id
            JOIN pickup_points pp ON pp.pickup_point_id = o.pickup_point_id
            JOIN order_statuses s ON s.status_id = o.status_id 
            LEFT JOIN order_items oi ON oi.order_id = o.order_id
            LEFT JOIN products ON p.product_id = o.product_id
            ORDER BY o.order_id, u.full_name, pp.address, s.name,o.order_date, o.delivery_date, o.receive_code
            ORDER BY o.order_id DESC
        """

        cursor.execute(query)
        return cursor.fetchall()

    finally:
        cursor.close()
        connection.close()

def get_order(order_id):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT
                order_id,
                client_id,
                pickup_point_id,
                status_id,
                order_date,
                delivery_date,
                receive_code
            FROM orders
            WHERE order_id = %s  
        """

        cursor.execute(query, (order_id,))
        order = cursor.fetchone()

        query_items = """
            SELECT p.article, oi.quantity
            FROM order_items oi
            JOIN products p ON p.product_id = oi.product_id
            WHERE oi.order_id = %s
        """

        cursor.execute(query_items, (order_id,))
        items = cursor.fetchall()

        return order, items
    finally:
        cursor.close()
        connection.close()

def get_product_choices():
    connection = connect_db()
    cursor = connection.close()

    try:
        query = """
            SELECT product_id, article, name
            FROM products
            ORDER BY name, article
        """

        cursor.execute(query)
        return cursor.fetchall()

    finally:
        cursor.close()
        connection.close()

def save_order(order_id, values, items):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        if order_id is None:
            query = """
                INSERT INTO orders
                (   
                    client_id,
                    pickup_point_id,
                    status_id,
                    order_date,
                    delivery_date,
                    receive_code
                )
                VALUES (%s,%s,%s,%s, %s, %s)
            """
            cursor.execute(query, values)
            order_id = cursor.lastrowid
        else:
            query = """
                UPDATE orders
                SET
                    client_id = %s,
                    pickup_point_id = %s,
                    status_id = %s,
                    order_date = %s,
                    delivery_date = %s,
                    receive_code = %s
                WHERE order_id = %s
            """
            cursor.execute("DELETE FROM order_items WHERE order_id = %s", (order_id,))

            for article, quantity in items:
                cursor.execute("SELECT product_id FROM products WHERE article = %s", (article,))

                result = cursor.fetchone()

                if result is None:
                    raise ValueError("Не найден товар с артикулом " + article)

                query = """
                    INSERT INTO order_items
                    (order_id, product_id, quantity)
                    VALUES (%s, %s, %s) 
                """
                cursor.execute(query,(order_id, result[0], quantity))
            connection.commit()

    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()

def delete_order(order_id):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        cursor.execute("DELETE FROM orders WHERE order_id = %s", (order_id,))

        connection.commit()

    except Exception:
        connection.rollback()
        raise
    finally:
        cursor.close()
        connection.close()