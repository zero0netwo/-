DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "stroymaterialy_db"
}