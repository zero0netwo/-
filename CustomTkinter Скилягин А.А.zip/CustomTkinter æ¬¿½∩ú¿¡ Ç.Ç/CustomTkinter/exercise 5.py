import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

window = ctk.CTk()
window.title("Анкета пользователя")
window.geometry("1080x760")

header = ctk.CTkLabel(window, text="Анкета пользователя", font=("Arial", 26, "bold"))
header.pack(pady=(30, 6))

subtitle = ctk.CTkLabel(window, text="Заполните информацию о себе", font=("Arial", 17))
subtitle.pack(pady=(0, 18))

entry_name = ctk.CTkEntry(window, placeholder_text="Введите ваше имя", width=400)
entry_name.pack(pady=8)

entry_age = ctk.CTkEntry(window, placeholder_text="Введите ваш возраст", width=400)
entry_age.pack(pady=8)

entry_city = ctk.CTkEntry(window, placeholder_text="Введите ваш город", width=400)
entry_city.pack(pady=8)

result_label = ctk.CTkLabel(window, text="", font=("Arial", 16), wraplength=400)
result_label.pack(pady=8)


def info():
    name = entry_name.get().strip()
    age = entry_age.get().strip()
    city = entry_city.get().strip()

    if not name or not age or not city:
        result_label.configure(text="Заполните все поля", text_color="red")
        return

    if not age.isdigit():
        result_label.configure(text="Возраст должен быть числом", text_color="red")
        return

    age_number = int(age)
    if not 1 <= age_number <= 120:
        result_label.configure(text="Введите корректный возраст", text_color="red")
        return

    result_label.configure(
        text=f"Ваше имя: {name}\nВозраст: {age_number}\nГород: {city}",
        text_color="green"
    )


def clear_entries():
    entry_name.delete(0, "end")
    entry_age.delete(0, "end")
    entry_city.delete(0, "end")
    result_label.configure(text="")


def close_app():
    window.destroy()


btn1 = ctk.CTkButton(window, text="Показать информацию", command=info)
btn1.pack(pady=(20, 8))

btn2 = ctk.CTkButton(window, text="Очистить", command=clear_entries)
btn2.pack(pady=8)

btn3 = ctk.CTkButton(window, text="Выход", command=close_app)
btn3.pack(pady=8)

window.mainloop()
