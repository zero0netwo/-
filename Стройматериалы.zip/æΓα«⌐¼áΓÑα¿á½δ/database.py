import mysql.connector
from config import DB_CONFIG


def connect_db():
    connection = mysql.connector.connect(**DB_CONFIG)

    return connection

def get_user(login, password):
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT users.user_id, users.full_name, roles.name
            FROM users
            JOIN roles ON users.role_id = roles.role_id
            WHERE users.login = %s AND users.password = %s
        """

        cursor.execute(query, (login, password))
        user = cursor.fetchone()

        return user

    finally:
        cursor.close()
        connection.close()


def get_tovars():
    connection = connect_db()
    cursor = connection.cursor()

    try:
        query = """
            SELECT
                products.article,
                products.name,
                categories.name,
                manufacturers.name,
                suppliers.name,
                units.name,
                products.price,
                products.discount,
                products.stock_quantity,
                products.description,
                products.image_path
                
                FROM products
                JOIN categories ON products.category_id = categories.category_id
                JOIN manufacturers ON products.manufacturer_id = manufacturers.manufacturer_id
                JOIN suppliers ON products.supplier_id = suppliers.supplier_id
                JOIN units ON products.unit_id = units.unit_id
                ORDER BY product_id
                """
        cursor.execute(query)
        result = cursor.fetchall()
        return result

    finally:
        cursor.close()
        connection.close()

