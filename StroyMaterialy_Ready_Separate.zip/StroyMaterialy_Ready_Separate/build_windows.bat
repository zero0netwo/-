@echo off
setlocal
cd /d "%~dp0"
python -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto :error
python -m PyInstaller --noconfirm --clean --onedir --windowed --name StroyMaterialy --icon resources\icon.ico --add-data "resources;resources" main.py
if errorlevel 1 goto :error
xcopy /E /I /Y "resources" "dist\StroyMaterialy\resources" >nul
copy /Y "settings.example.ini" "dist\StroyMaterialy\settings.example.ini" >nul
copy /Y "README.md" "dist\StroyMaterialy\README.md" >nul
echo.
echo BUILD COMPLETE: dist\StroyMaterialy\StroyMaterialy.exe
echo COPY settings.example.ini TO settings.ini AND ENTER MYSQL PASSWORD.
pause
exit /b 0
:error
echo BUILD FAILED. Check Python, internet for dependencies and PyInstaller output.
pause
exit /b 1
