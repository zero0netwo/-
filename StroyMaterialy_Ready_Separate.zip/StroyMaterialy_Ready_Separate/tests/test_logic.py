import unittest
from decimal import Decimal
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from logic import (as_money, as_count, as_decimal, final_price, money_text, filter_and_sort,
                   product_background, parse_date)

DATA = [
    dict(product_id=1, article='A', name='Цемент', description='м500', category='Смеси',
         manufacturer='М500', supplier='Поставщик', unit='шт.', price=Decimal('440.00'),
         discount=Decimal('15'), stock_quantity=0),
    dict(product_id=2, article='B', name='Краска', description='Белая', category='Краски',
         manufacturer='Knauf', supplier='Другой', unit='шт.', price=Decimal('220.00'),
         discount=Decimal('8'), stock_quantity=22),
]

class Calculations(unittest.TestCase):
    def test_price(self):
        self.assertEqual(final_price(2400, 20), Decimal('1920.00'))
        self.assertEqual(final_price(1000, 15), Decimal('850.00'))
        self.assertEqual(money_text(1250.3), '1 250,30 ₽')
    def test_colors(self):
        self.assertEqual(product_background(0, 15), '#D8EDF9')
        self.assertEqual(product_background(1, 13), '#F4A460')
        self.assertEqual(product_background(1, 12), '#FFFFFF')
    def test_input(self):
        self.assertEqual(as_money('12,34'), Decimal('12.34'))
        self.assertEqual(as_count('0'), 0)
        for value in ('-1', 'abc', 'NaN'):
            with self.assertRaises(ValueError): as_money(value)
        for value in ('-1','1.5','abc'):
            with self.assertRaises(ValueError): as_count(value)
        self.assertEqual(as_decimal('12', 'скидка', 100), Decimal('12'))
    def test_dates(self):
        self.assertIsNone(parse_date('', 'Дата заказа', required=False))
        with self.assertRaises(ValueError): parse_date('2025-02-30', 'Дата заказа')
    def test_search_and_filter(self):
        result = filter_and_sort(DATA, 'краска knauf')
        self.assertEqual([r['product_id'] for r in result], [2])
        self.assertEqual(len(filter_and_sort(DATA, manufacturer='М500')), 1)
        self.assertEqual([p['product_id'] for p in filter_and_sort(DATA, sorting='Цена: по убыванию')], [1, 2])
        self.assertEqual([p['product_id'] for p in filter_and_sort(DATA, sorting='Остаток: по убыванию')], [2, 1])
        self.assertEqual([p['product_id'] for p in filter_and_sort(DATA, sorting='Скидка: по убыванию')], [1, 2])
        self.assertEqual(filter_and_sort(DATA, 'XYZ'), [])

if __name__ == '__main__': unittest.main()
