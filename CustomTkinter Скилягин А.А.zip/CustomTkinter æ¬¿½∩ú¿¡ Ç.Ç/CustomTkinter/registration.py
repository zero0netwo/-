import customtkinter as ctk

ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

window = ctk.CTk()
window.title("Окно регистрации")
window.geometry("750x450")

title_label = ctk.CTkLabel(
    window, text="Регистрация пользователя", font=("Arial", 24, "bold")
)
title_label.pack(pady=(25, 5))

subtitle_label = ctk.CTkLabel(window, text="Заполните все поля")
subtitle_label.pack(pady=(0, 15))

name_entry = ctk.CTkEntry(window, placeholder_text="Введите имя", width=400)
name_entry.pack(pady=8)

login_entry = ctk.CTkEntry(window, placeholder_text="Введите логин", width=400)
login_entry.pack(pady=8)

password_entry = ctk.CTkEntry(
    window, placeholder_text="Введите пароль", width=400, show="*"
)
password_entry.pack(pady=8)

error = ctk.CTkLabel(window, text="", wraplength=600)
error.pack(pady=8)


def get_entry():
    name = name_entry.get().strip()
    login = login_entry.get().strip()
    password = password_entry.get().strip()

    if not name or not login or not password:
        error.configure(text="Ошибка! Заполните все поля.", text_color="red")
        return

    error.configure(
        text=f"Регистрация заполнена!\nВаше имя: {name}\nВаш логин: {login}",
        text_color="lightgreen",
    )


def clear_entries():
    name_entry.delete(0, "end")
    login_entry.delete(0, "end")
    password_entry.delete(0, "end")
    error.configure(text="")


btn = ctk.CTkButton(window, text="Зарегистрироваться", command=get_entry)
btn.pack(pady=7)

clear_btn = ctk.CTkButton(window, text="Очистить", command=clear_entries)
clear_btn.pack(pady=7)

exit_btn = ctk.CTkButton(window, text="Выход", command=window.destroy)
exit_btn.pack(pady=7)

window.mainloop()
