"""Запуск приложения ООО «СтройМатериалы»."""
import tkinter as tk
from tkinter import messagebox
from config import RESOURCE_DIR
from ui_common import setup_style, clear


class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.geometry('1120x750')
        self.minsize(900, 570)
        setup_style(self)
        try:
            self.iconbitmap(str(RESOURCE_DIR / 'icon.ico'))
        except (tk.TclError, OSError):
            pass
        self.editor = None
        self.show_login()

    def show_login(self):
        from auth_window import render_login
        clear(self)
        self.title('СтройМатериалы — Авторизация')
        render_login(self)

    def show_catalog(self, user):
        from main_window import Catalog
        clear(self)
        self.title('СтройМатериалы — Каталог товаров')
        Catalog(self, user)

    def show_orders(self, user):
        if not user or user.get('role') not in ('Менеджер', 'Администратор'):
            messagebox.showwarning('Доступ запрещён', 'Просмотр заказов доступен только сотрудникам.')
            return
        from orders_window import OrdersWindow
        clear(self)
        self.title('СтройМатериалы — Заказы')
        OrdersWindow(self, user)


if __name__ == '__main__':
    Application().mainloop()
